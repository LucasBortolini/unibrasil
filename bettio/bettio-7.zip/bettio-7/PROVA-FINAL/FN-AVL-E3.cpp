#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct DISPOSITIVO
{
	int codigo;
	char nome[20];
    char macAdress[12];
};

int main()
{
	struct DISPOSITIVO dispositivo ;	
	
    printf("Digite o nome do dispositivo:\n ");
  	scanf("%s", &dispositivo.nome);

  	printf("Digite o codigo do dispositivo:\n");
 	scanf("%d", &dispositivo.codigo);
 	
 	printf("Digite o endereco MacAdress:\n");
  	scanf("%s", &dispositivo.macAdress);
  	
	// Mostrando na tela os dados inseridos pelo usuário.
  	printf("Dados do Dispositivo:\n");
  	printf("Nome: %s\n", dispositivo.nome);
  	printf("Codigo: %d\n", dispositivo.codigo);
  	printf("Endereco: %s\n", dispositivo.macAdress);
	
	return(0);
    
  }