#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct CLIENTE
{
  char nome[20];
  int  idade;
  char cidade[20];
};
int main() {
  
  struct CLIENTE cliente1;
  printf("Digite o nome do cliente:\n ");
  scanf("%s", cliente1.nome);

  printf("Digite a idade do cliente:\n");
  scanf("%d", &cliente1.idade);
  
  printf("Digite a cidade do cliente:\n");
  scanf("%s", cliente1.cidade);
  
  printf("Dados do cliente:\n");
  printf("Nome: %s\n", cliente1.nome);
  printf("Idade: %d\n", cliente1.idade);
  printf("Cidade: %s\n", cliente1.cidade);
  return 0;
  system("pause");
}
