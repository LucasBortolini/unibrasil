INSERT into tbProjeto (numero_projeto, nome_projeto, data_inicio, data_final, CPF_pessoa) 
VALUES (1, "projeto 1", "24/03/1999", "08/08/2022", "03203203212")
