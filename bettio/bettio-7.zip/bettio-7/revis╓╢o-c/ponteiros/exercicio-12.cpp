// 12. Faça um programa em C que crie uma estrutura para representar um ponto no plano cartesiano e use ponteiros para manipular essa estrutura.

#include <stdio.h>

typedef struct {
    float x;
    float y;
} Ponto;

void moverPonto(Ponto *p, float dx, float dy) {
    p->x += dx;
    p->y += dy;
}

int main() {
    Ponto ponto1 = {3.5, 5.2};
    printf("Ponto original: (%.1f, %.1f)\n", ponto1.x, ponto1.y);
    
    moverPonto(&ponto1, 2.0, -1.5); // Move o ponto
    printf("Novo ponto: (%.1f, %.1f)\n", ponto1.x, ponto1.y);
    
    return 0;
}
