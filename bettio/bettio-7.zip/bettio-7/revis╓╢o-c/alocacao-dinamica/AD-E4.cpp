/*  

    4) Crie um programa em C que preencha uma struct CADASTRO com duas subtructs ENDERECO (comercial e residencial) usando scanf, 
       depois do preenchimento imprima todo seu conteúdo. Sem alocação estática, apenas ponteiros e malloc.
*/
#include <stdio.h>
#include <stdlib.h>

// Definição da estrutura ENDERECO
struct ENDERECO 
{
    char rua[50];
    int numero;
    char cidade[50];
    char estado[3];
};

// Definição da estrutura CADASTRO com duas subestruturas ENDERECO
struct CADASTRO 
{
    struct ENDERECO *comercial;
    struct ENDERECO *residencial;
};

int main() {
    // Alocação de memória para as subestruturas ENDERECO
    struct ENDERECO *endereco_comercial = (struct ENDERECO *)malloc(sizeof(struct ENDERECO));
    struct ENDERECO *endereco_residencial = (struct ENDERECO *)malloc(sizeof(struct ENDERECO));

    // Verificação se a alocação de memória foi bem-sucedida
    if (endereco_comercial == NULL || endereco_residencial == NULL) 
    {
        printf("Erro: Falha na alocação de memória.\n");
        return 1;
    }

    // Preenchimento do endereço comercial
    printf("Digite o endereço comercial:\n");
    printf("Rua: ");
    scanf("%s", endereco_comercial->rua);
    printf("Número: ");
    scanf("%d", &endereco_comercial->numero);
    printf("Cidade: ");
    scanf("%s", endereco_comercial->cidade);
    printf("Estado: ");
    scanf("%s", endereco_comercial->estado);

    // Preenchimento do endereço residencial
    printf("\nDigite o endereço residencial:\n");
    printf("Rua: ");
    scanf("%s", endereco_residencial->rua);
    printf("Número: ");
    scanf("%d", &endereco_residencial->numero);
    printf("Cidade: ");
    scanf("%s", endereco_residencial->cidade);
    printf("Estado: ");
    scanf("%s", endereco_residencial->estado);

    // Alocação de memória para a estrutura CADASTRO
    struct CADASTRO *cadastro = (struct CADASTRO *)malloc(sizeof(struct CADASTRO));

    // Verificação se a alocação de memória foi bem-sucedida
    if (cadastro == NULL) 
    {
        printf("Erro: Falha na alocação de memória.\n");
        return 1;
    }

    // Atribuição dos endereços às subestruturas CADASTRO
    cadastro->comercial = endereco_comercial;
    cadastro->residencial = endereco_residencial;

    // Impressão dos dados cadastrados
    printf("\nDados cadastrados:\n");
    printf("Endereço Comercial:\n");
    printf("Rua: %s\n", cadastro->comercial->rua);
    printf("Número: %d\n", cadastro->comercial->numero);
    printf("Cidade: %s\n", cadastro->comercial->cidade);
    printf("Estado: %s\n", cadastro->comercial->estado);
    printf("\nEndereço Residencial:\n");
    printf("Rua: %s\n", cadastro->residencial->rua);
    printf("Número: %d\n", cadastro->residencial->numero);
    printf("Cidade: %s\n", cadastro->residencial->cidade);
    printf("Estado: %s\n", cadastro->residencial->estado);

    // Liberação da memória alocada
    free(endereco_comercial);
    free(endereco_residencial);
    free(cadastro);

    return 0;
}