#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <locale.h>

struct DADOS {

  char nome [50];
  char telefone [19];

};

int main (void) {

  setlocale(LC_ALL, "portuguese");
  
}