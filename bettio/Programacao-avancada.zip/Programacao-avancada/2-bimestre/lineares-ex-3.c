#include <stdio.h>
#include <stdlib.h>

struct NO {
    int info;
    struct NO* proximo;
};

void inserirNoInicio(struct NO** lista, int dado) {
    struct NO* novoNo = (struct NO*)malloc(sizeof(struct NO));
    novoNo->info = dado;
    novoNo->proximo = *lista;
    *lista = novoNo;
}

void imprimirLista(struct NO* lista) {
    struct NO* atual = lista;
    while (atual != NULL) {
        printf("%d ", atual->info);
        atual = atual->proximo;
    }
    printf("\n");
}

void liberarLista(struct NO** lista) {
    struct NO* atual = *lista;
    while (atual != NULL) {
        struct NO* proximo = atual->proximo;
        free(atual);
        atual = proximo;
    }
    *lista = NULL;
}

int main() {
    struct NO* lista = NULL;
    int opcao = 0;
    char buffer[100];

    do {
        printf("\nMenu de Opcoes:\n");
        printf("1. Aloca um no automatico no inicio\n");
        printf("2. Imprime todos os nos\n");
        printf("3. Sair do programa\n");
        printf("Escolha uma opcao: ");

        fgets(buffer, sizeof(buffer), stdin);
        sscanf(buffer, "%d", &opcao);

        switch (opcao) {
            case 1: {
                int dado;
                printf("Digite o valor do no: ");
                fgets(buffer, sizeof(buffer), stdin);
                sscanf(buffer, "%d", &dado);
                inserirNoInicio(&lista, dado);
                printf("No alocado com sucesso!\n");
                break;
            }
            case 2: {
                printf("Lista de nos: ");
                imprimirLista(lista);
                break;
            }
            case 3: {
                printf("Encerrando o programa...\n");
                liberarLista(&lista);
                break;
            }
            default: {
                printf("Opcao invalida! Tente novamente.\n");
                break;
            }
        }
    } while (opcao != 3);

    return 0;
}
