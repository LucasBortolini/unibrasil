import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint
from tensorflow.keras.optimizers import Adam

# Ler o arquivo CSV treinamento_alunos com base nas colunas selecionadas do TXT
with open('colunas_carregadas.txt', 'r') as arquivo:
    colunas_usadas = arquivo.read().splitlines()

dados_treinamento = pd.read_csv('dataset/treinamento_alunos.csv', usecols=colunas_usadas)

# Tratando colunas categóricas no conjunto de dados
categoricas = dados_treinamento.select_dtypes(include=['object']).columns
preprocessador = ColumnTransformer(transformers=[('cat', OneHotEncoder(), categoricas)], remainder='passthrough')
X = preprocessador.fit_transform(dados_treinamento.drop(columns=['NU_NOTA_REDACAO']))
y = dados_treinamento['NU_NOTA_REDACAO']

# Verificando e substituindo NaN nos dados de entrada
X = np.nan_to_num(X)
y = y.fillna(y.mean())  # Substitui NaN no y pela média

# Dividir o conjunto de dados em treino (80%) e teste (20%)
X_treino, X_teste, y_treino, y_teste = train_test_split(X, y, test_size=0.2, random_state=42)

# Construção da rede neural com 28 neurônios na camada oculta
modelo = Sequential()
modelo.add(Dense(28, activation='relu', input_shape=(X_treino.shape[1],)))
modelo.add(Dropout(0.5))
modelo.add(Dense(1, activation='linear'))

# Definindo o otimizador Adam com uma taxa de aprendizado específica
learning_rate = 0.001  # Ajuste este valor conforme necessário
otimizador = Adam(learning_rate=learning_rate)

# Compilação do modelo
modelo.compile(optimizer=otimizador, loss='mean_squared_error', metrics=['mean_squared_error'])

# Definindo callback para parar o treinamento cedo caso a validação não melhore
early_stopping = EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True)

# Definindo callback para salvar os melhores pesos
checkpoint_filepath = 'melhor_modelo.keras'
model_checkpoint = ModelCheckpoint(filepath=checkpoint_filepath, monitor='val_loss', save_best_only=True, mode='min')

# Treinamento do modelo
historico = modelo.fit(X_treino, y_treino, epochs=100, batch_size=32, verbose=1, validation_data=(X_teste, y_teste), callbacks=[early_stopping, model_checkpoint])

# Carregar os melhores pesos salvos
modelo.load_weights(checkpoint_filepath)

# Fazer previsões no conjunto de teste
previsoes_teste = modelo.predict(X_teste)

# Verificando e substituindo NaN nas previsões
previsoes_teste = np.nan_to_num(previsoes_teste)

# Avaliar o modelo
mse_teste = mean_squared_error(y_teste, previsoes_teste)
r2_teste = r2_score(y_teste, previsoes_teste)

print('Erro quadrático médio (MSE) no conjunto de teste:', mse_teste)
print('Coeficiente de determinação (R²) no conjunto de teste:', r2_teste)
