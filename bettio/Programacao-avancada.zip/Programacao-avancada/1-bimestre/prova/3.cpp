#include <stdio.h>

int main () 
{
  int i, *p;
  i = 3;
  p = &i;
  printf("%d\n", i);// retorna variavel 3
  printf("%x\n", p);// retorna o endereço de memoria i
  printf("%x\n", &i);// retorna o endereço de memoria i
  printf("%p\n", &p);// retorna o endereço de memoria p
}