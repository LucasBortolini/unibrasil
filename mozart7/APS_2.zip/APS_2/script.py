import pandas as pd
import numpy as np
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, BatchNormalization
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.regularizers import l2

# Definição dos caminhos dos arquivos
colunas_arquivo = 'colunas_carregadas.txt'
dados_treino_arquivo = 'dataset/treinamento_alunos.csv'
dados_teste_arquivo = 'dataset/teste_alunos.csv'
modelo_pesos_arquivo = 'best_model.keras'
resultados_saida_arquivo = 'dataset/planilha_com_previsoes.csv'

# Carregar a lista de colunas a partir do arquivo
with open(colunas_arquivo, 'r') as f:
    colunas_selecionadas = f.read().splitlines()

# Verificar se 'NU_NOTA_REDACAO' está na lista de colunas carregadas
if 'NU_NOTA_REDACAO' not in colunas_selecionadas:
    raise ValueError("A coluna 'NU_NOTA_REDACAO' não está presente no arquivo 'colunas_carregadas.txt'.")

# Carregar o conjunto de dados de treinamento
dados_treino = pd.read_csv(dados_treino_arquivo, usecols=colunas_selecionadas)

# Validar a presença da coluna 'NU_NOTA_REDACAO'
if 'NU_NOTA_REDACAO' not in dados_treino.columns:
    raise ValueError("A coluna 'NU_NOTA_REDACAO' não está presente no DataFrame carregado.")

# Identificar colunas categóricas e numéricas
colunas_categoricas = dados_treino.select_dtypes(include=['object']).columns
colunas_numericas = dados_treino.select_dtypes(exclude=['object']).columns.drop('NU_NOTA_REDACAO')

# Preenchimento de NaNs nas colunas numéricas com a média da coluna
dados_treino[colunas_numericas] = dados_treino[colunas_numericas].fillna(dados_treino[colunas_numericas].mean())

# Preenchimento de NaNs nas colunas categóricas com o valor mais frequente (moda)
dados_treino[colunas_categoricas] = dados_treino[colunas_categoricas].fillna(dados_treino[colunas_categoricas].mode().iloc[0])

# Seleção e processamento de colunas categóricas e numéricas
transformador = ColumnTransformer([
    ('categorico', OneHotEncoder(), colunas_categoricas),
    ('numerico', StandardScaler(), colunas_numericas)
], remainder='passthrough')

# Aplicar o transformador aos dados de entrada
X_treino_transformado = transformador.fit_transform(dados_treino.drop(columns=['NU_NOTA_REDACAO']))
y_treino_transformado = dados_treino['NU_NOTA_REDACAO']

# Dividir o conjunto de dados em treino e teste
X_treino, X_validacao, y_treino, y_validacao = train_test_split(
    X_treino_transformado, y_treino_transformado, test_size=0.2, random_state=42)

# Configuração da rede neural
rede_neural = Sequential([
    Dense(64, activation='relu', input_shape=(X_treino.shape[1],), kernel_regularizer=l2(0.001)),
    BatchNormalization(),
    Dropout(0.5),
    Dense(32, activation='relu', kernel_regularizer=l2(0.001)),
    BatchNormalization(),
    Dropout(0.5),
    Dense(1, activation='linear')
])

# Configurar o otimizador Adam com taxa de aprendizado
taxa_aprendizado = 0.001
otimizador_adam = Adam(learning_rate=taxa_aprendizado)

# Compilação da rede neural
rede_neural.compile(optimizer=otimizador_adam, loss='mean_squared_error', metrics=['mean_squared_error'])

# Definir callbacks para EarlyStopping, ModelCheckpoint e ReduceLROnPlateau
early_stop_callback = EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)
checkpoint_callback = ModelCheckpoint(filepath=modelo_pesos_arquivo, monitor='val_loss', save_best_only=True, mode='min')
reduce_lr_callback = ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=5, min_lr=1e-6)

# Treinar o modelo
historico_treinamento = rede_neural.fit(
    X_treino, y_treino, epochs=200, batch_size=32, verbose=1,
    validation_data=(X_validacao, y_validacao), callbacks=[early_stop_callback, checkpoint_callback, reduce_lr_callback])

# Carregar os melhores pesos salvos
rede_neural.load_weights(modelo_pesos_arquivo)

# Avaliar o modelo no conjunto de validação
previsoes_validacao = rede_neural.predict(X_validacao)

# Calcular e exibir métricas de avaliação
mse_validacao = mean_squared_error(y_validacao, previsoes_validacao)
r2_validacao = r2_score(y_validacao, previsoes_validacao)

print('Avaliação do Modelo:')
print(f'Erro quadrático médio (MSE): {mse_validacao}')
print(f'Coeficiente de determinação (R²): {r2_validacao}')

# Carregar o conjunto de dados para inferência
dados_teste = pd.read_csv(dados_teste_arquivo, usecols=colunas_selecionadas)

# Preenchimento de NaNs nas colunas numéricas com a média da coluna
dados_teste[colunas_numericas] = dados_teste[colunas_numericas].fillna(dados_teste[colunas_numericas].mean())

# Preenchimento de NaNs nas colunas categóricas com o valor mais frequente (moda)
dados_teste[colunas_categoricas] = dados_teste[colunas_categoricas].fillna(dados_teste[colunas_categoricas].mode().iloc[0])

# Verificar se as colunas categóricas estão presentes nos dados de inferência
if not set(colunas_categoricas).issubset(dados_teste.columns):
    raise ValueError("As colunas categóricas necessárias estão faltando no conjunto de dados de inferência.")

# Aplicar o transformador aos dados de inferência
X_inferencia_transformado = transformador.transform(dados_teste.drop(columns=['NU_NOTA_REDACAO']))

# Fazer previsões no conjunto de dados de inferência
previsoes_inferencia = rede_neural.predict(X_inferencia_transformado)

# Adicionar as previsões ao DataFrame de inferência
dados_teste['NU_NOTA_REDACAO'] = previsoes_inferencia

# Salvar as previsões em um novo arquivo CSV
dados_teste.to_csv(resultados_saida_arquivo, index=False)

print(f'Previsões salvas com sucesso no arquivo: {resultados_saida_arquivo}')
