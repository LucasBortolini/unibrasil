// 3.  Faça um programa em C que declare um array de inteiros e use ponteiros para imprimir os elementos do array.

#include <stdio.h>

int main() {
    int array[] = {1, 2, 3, 4, 5};
    int *ptr = array; // Ponteiro para o primeiro elemento do array
    
    printf("Elementos do array: ");
    for (int i = 0; i < 5; i++) {
        printf("%d ", *ptr); // Imprime o valor apontado pelo ponteiro
        ptr++; // Move o ponteiro para o próximo elemento
    }
    printf("\n");
    
    return 0;
}
