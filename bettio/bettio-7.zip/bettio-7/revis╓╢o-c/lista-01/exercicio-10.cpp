// 10. Crie um programa capaz de criar a transposta de uma matriz. A matriz deve ser lida de teclado.

#include <stdio.h>

#define LINHAS 3
#define COLUNAS 3

void transporMatriz(int matriz[LINHAS][COLUNAS], int transposta[COLUNAS][LINHAS]) {
    for (int i = 0; i < LINHAS; i++) {
        for (int j = 0; j < COLUNAS; j++) {
            transposta[j][i] = matriz[i][j];
        }
    }
}

int main() {
    int matriz[LINHAS][COLUNAS], transposta[COLUNAS][LINHAS];

    printf("Digite os elementos da matriz %dx%d:\n", LINHAS, COLUNAS);
    for (int i = 0; i < LINHAS; i++) {
        for (int j = 0; j < COLUNAS; j++) {
            scanf("%d", &matriz[i][j]);
        }
    }

    transporMatriz(matriz, transposta);

    printf("Matriz transposta:\n");
    for (int i = 0; i < COLUNAS; i++) {
        for (int j = 0; j < LINHAS; j++) {
            printf("%d ", transposta[i][j]);
        }
        printf("\n");
    }

    return 0;
}
