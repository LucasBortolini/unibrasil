#include <stdio.h>

int main (void) 
{
  int x;
  int y = 4;
  float salario = 3400;
  char sexo = 'M';

  printf("X: %d\n", x);
  printf("o valor de y e: %d\n", y);
  printf("seu salario sera de %.2f\n", salario);
  printf("Sexo: %c\n", sexo);

  // %d     inteiro decimal
  // %f     float
  // %lf    double
  // %c     char
  // %s     string
}
