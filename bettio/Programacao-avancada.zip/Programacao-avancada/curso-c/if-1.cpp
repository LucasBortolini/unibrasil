#include <iostream>

using namespace std;

int main() {

  // int dinheiro = 20;

  // if(dinheiro > 10) {

  //   cout << "Eu vou ao cinema" << endl;
  // } else {
  //   cout << "Não vou ao cinema" << endl;
  // }

  int num = 10;

  if(num >= 10) {
    cout << "numero maior ou igual a 10" << endl;
  }
  return 0;
}