// 13. Escreva um programa em C que implemente uma lista ligada simples e tenha funções para inserção, remoção e impressão dos elementos.

#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node *next;
} Node;

Node *criarNo(int valor) {
    Node *novoNo = (Node *)malloc(sizeof(Node));
    novoNo->data = valor;
    novoNo->next = NULL;
    return novoNo;
}

void inserir(Node **head, int valor) {
    Node *novoNo = criarNo(valor);
    novoNo->next = *head;
    *head = novoNo;
}

void remover(Node **head, int valor) {
    Node *temp = *head, *prev = NULL;
    if (temp != NULL && temp->data == valor) {
        *head = temp->next;
        free(temp);
        return;
    }
    while (temp != NULL && temp->data != valor) {
        prev = temp;
        temp = temp->next;
    }
    if (temp == NULL) return;
    prev->next = temp->next;
    free(temp);
}

void imprimirLista(Node *head) {
    Node *temp = head;
    while (temp != NULL) {
        printf("%d ", temp->data);
        temp = temp->next;
    }
    printf("\n");
}

int main() {
    Node *lista = NULL;
    inserir(&lista, 10);
    inserir(&lista, 20);
    inserir(&lista, 30);
    inserir(&lista, 40);
    printf("Lista inicial: ");
    imprimirLista(lista);

    remover(&lista, 20);
    printf("Lista após a remoção do valor 20: ");
    imprimirLista(lista);

    return 0;
}
