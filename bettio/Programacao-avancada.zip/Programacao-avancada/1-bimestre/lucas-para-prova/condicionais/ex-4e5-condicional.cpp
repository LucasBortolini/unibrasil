// 5 - Leia 4 notas, calcule a média e informe se o aluno passou por média, ficou de exame ou reprovou direto. Se o aluno ficou de exame, solicite a nota do exame e informe se o aluno passou ou reprovou;

#include <stdio.h>

int main(void) {

  float nota1, nota2, nota3, nota4, exame;
  
  fflush(stdin);
  printf("digite a primeira nota\n");
  scanf("%f", &nota1);

  fflush(stdin);
  printf("digite a segunda nota\n");
  scanf("%f", &nota2);

  fflush(stdin);
  printf("digite a terceira nota\n");
  scanf("%f", &nota3);

  fflush(stdin);
  printf("digite a quarta nota\n");
  scanf("%f", &nota4);

  float media = ((nota1 + nota2 + nota3 + nota4) / 4);
  
  if(media >= 7)
  {
    printf("o aluno passou com media:%.1f\n", media);
  }
  else if (media < 7)
  {
    printf("o aluno foi para exame pois ficou com media:%.1f\n", media);
    printf("digite a nota do exame\n");
    scanf("%f", &exame);

    if (exame >= 7)
    {
      printf("o aluno passou com media:%.1f\n", exame);
    }
    else if ((exame > media) && (exame < 7))
    {
      printf("o aluno reprovou com media:%.1f\n", exame);
    }
    else
    {
      printf("o aluno reprovou com media:%.1f\n", media); 
    }
  }  
}
