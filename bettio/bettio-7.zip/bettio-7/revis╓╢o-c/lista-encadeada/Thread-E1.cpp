#include <stdio.h>
#include <stdlib.h>
#include <process.h>
#include <windows.h>
#include <conio.h>

void gotoxy(int x, int y);
void animacao(void*);

int main()
{
    int i;
    HANDLE threads[5];

    // Criação das threads
    for (i = 0; i < 5; i++)
    {
        threads[i] = (HANDLE)_beginthread(animacao, 0, (void*)i);
    }

    // Aguarda a finalização das threads
    WaitForMultipleObjects(5, threads, TRUE, INFINITE);

    printf("\nAnimação concluída. Pressione qualquer tecla para sair.\n");
    getch();

    return 0;
}

void gotoxy(int x, int y)
{
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

void animacao(void* arg)
{
    int id = (int)arg;
    int x = 0;
    int y = id * 2;

    while (x < 80)
    {
        gotoxy(x, y);
        printf("*");
        Sleep(100);

        gotoxy(x, y);
        printf(" ");

        x += 2;
    }

    _endthread();
}
