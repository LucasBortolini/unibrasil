#include <stdio.h>

int main (void) 
{
  int x;
  int y;

  fflush(stdin); // limpeza de buffer
  printf("Digite o primeiro numero: \n");
  scanf("%d", &x);

  fflush(stdin); // limpeza de buffer
  printf("Digite o segundo numero: \n");
  scanf("%d", &y);

  printf("a soma de X e Y e = %d\n", x + y);
  printf("a subtracao de X e Y e = %d\n", x - y);


  // %d     inteiro decimal
  // %f     float
  // %lf    double
  // %c     char
  // %s     string
}
