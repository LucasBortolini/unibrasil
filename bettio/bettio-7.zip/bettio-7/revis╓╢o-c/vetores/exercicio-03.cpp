// 3.  Escreva um programa em C que verifique se um n�mero fornecido pelo usu�rio est� presente em um vetor de 10 elementos.

#include <stdio.h>

#define TAMANHO_VETOR 10

int main() {
    int vetor[TAMANHO_VETOR];
    int numero;
    int i;
    int encontrado = 0;

    printf("Digite %d números para preencher o vetor:\n", TAMANHO_VETOR);
    for (i = 0; i < TAMANHO_VETOR; i++) {
        scanf("%d", &vetor[i]);
    }

    printf("Digite o número a ser procurado no vetor: ");
    scanf("%d", &numero);

    for (i = 0; i < TAMANHO_VETOR; i++) {
        if (vetor[i] == numero) {
            encontrado = 1;
            break;
        }
    }

    if (encontrado) {
        printf("O número %d está presente no vetor.\n", numero);
    } else {
        printf("O número %d não está presente no vetor.\n", numero);
    }

    return 0;
}
