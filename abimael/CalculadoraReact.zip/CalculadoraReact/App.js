import React from "react";
import {StyleSheet, Text, View, TouchableOpacity} from "react-native";
import {useState} from "react";


export default function App() {
  const [conta, setConta] = useState("0");
  const [historico, setHistorico] = useState("");

  const botoes = ["C", "DEL", "/", 7, 8, 9, "*", 4, 5, 6, "-", 1, 2, 3, "+", 0, ",", "="]

  function calcular() {
    let ultimo = conta[conta.length-1];
    
    if(ultimo === "/" || ultimo === "*" || ultimo === "-" || ultimo === "+" || ultimo === ",") {
      setConta(conta);
      return;
    }
    else {
      let contaSemVirgula = conta.replace(/,/g , ".");
      let resultado = eval(contaSemVirgula).toString();
      let resultadoComVirgula = resultado.replace(/\./g , ",");
      setHistorico(conta + "=" + resultadoComVirgula);
      setConta(resultadoComVirgula);
      return;
    }
  }

  function adicionar(expressao) {
    if (conta == "0") {
      setConta(expressao);
    } else {
      setConta(conta + expressao);
    }
  }

  function lidarinsercao(botao) {
    if(botao  === "+" || botao === "-" || botao === "*" || botao === "/") {
      adicionar(botao);
    }
    else if ([1, 2, 3, 4, 5, 6, 7, 8, 9, 0, ","].includes(botao)) {
      adicionar(botao);
    }
    else {
      switch(botao) {
        case "DEL":
          setConta(conta.substring(0, (conta.length - 1)));
          return;
        case "C":
          setHistorico("");
          setConta("0");
          return;
        case "=":
          calcular();
          return;
      }
    }
  }

  const styles = StyleSheet.create({
    resultados: {
      backgroundColor: "#282f3b",
      maxWidth: "100%",
      minHeight: "35%",
      alignItems: "flex-end",
      justifyContent: "flex-end",
    },
    textoResultado: {
      maxHeight: 45,
      color: "#e27396",
      margin: 15,
      fontSize: 35,
    },
    textoHistorico: {
      color: "#B5B7BB",
      fontSize: 20,
      marginRight: 10,
      alignSelf: "flex-end",
    },
    botoes: {
      width: "100%",
      height: "35%",
      flexDirection: "row",
      flexWrap: "wrap",
    },
    botao: {
      borderColor: "#3f4d5b",
      alignItems: "center",
      justifyContent: "center",
      minWidth: "24%",
      minHeight: "54%",
      flex: 2,
    },
    textoBotao: {
      color: "#b5b7bb",
      fontSize: 28,
    },
    credenciais: {
      position: "absolute",
      left: 10,
      top: 50,
      color: "white",
      fontSize: 20,
    },
  });

  return(
    <View>
      <View style={styles.resultados}>
        <Text style={styles.credenciais}>Nome: Lucas Sales{'\n'}RA: 2021102614</Text>
        <Text style={styles.textoHistorico}>{historico}</Text>
        <Text style={styles.textoResultado}>{conta}</Text>
      </View>
      <View style={styles.botoes}>
        {botoes.map((botao) =>
          (["=","/","-","*","+"].includes(botao)) ?
          <TouchableOpacity key={botao} style={[styles.botao, {backgroundColor: "#e27396"} ]} onPress={() => lidarinsercao(botao)}>
            <Text style={[styles.textoBotao, {color: "white", fontSize: 28} ]}>{botao}</Text>
          </TouchableOpacity>
          :
          botao === 0 ?
          <TouchableOpacity key={botao} style={[styles.botao, {backgroundColor: typeof(botao) === "number" ? "#303946" : "#414853", minWidth: "36%"} ]} onPress={() => lidarinsercao(botao)}>
            <Text style={styles.textoBotao}>{botao}</Text>
          </TouchableOpacity>
          :
          botao === "," || botao === "DEL" ?
          <TouchableOpacity key={botao} style={[styles.botao, {backgroundColor: botao === "," ? "#303946" : "#414853", minWidth: "37%"} ]} onPress={() => lidarinsercao(botao)}>
            <Text style={styles.textoBotao}>{botao}</Text>
          </TouchableOpacity>
          :
          botao === "C" ?
          <TouchableOpacity key={botao} style={[styles.botao, {backgroundColor: typeof(botao) === "number" ? "#303946" : "#414853", minWidth: "36%"} ]} onPress={() => lidarinsercao(botao)}>
            <Text style={styles.textoBotao}>{botao}</Text>
          </TouchableOpacity>
          :
          <TouchableOpacity key={botao} style={[styles.botao, {backgroundColor: typeof(botao) === "number" ? "#303946" : "#414853" } ]} onPress={() => lidarinsercao(botao)}>
            <Text style={styles.textoBotao}>{botao}</Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}