// 15. Crie uma função capaz de somar os elementos das linhas L1 e L2 de uma matriz. O resultado deve ser colocado na linha L2. Faça o mesmo com a multiplicação.

#include <stdio.h>

#define COLUNAS 3

void somarLinhas(int matriz[COLUNAS][COLUNAS], int linha1, int linha2) {
    for (int j = 0; j < COLUNAS; j++)
        matriz[linha2][j] += matriz[linha1][j];
}

void multiplicarLinhas(int matriz[COLUNAS][COLUNAS], int linha1, int linha2) {
    for (int j = 0; j < COLUNAS; j++)
        matriz[linha2][j] *= matriz[linha1][j];
}

int main() {
    int matriz[COLUNAS][COLUNAS], linha1, linha2;

    printf("Digite os elementos da matriz %dx%d:\n", COLUNAS, COLUNAS);
    for (int i = 0; i < COLUNAS; i++) {
        for (int j = 0; j < COLUNAS; j++) {
            scanf("%d", &matriz[i][j]);
        }
    }

    printf("Digite o número da primeira linha: ");
    scanf("%d", &linha1);
    printf("Digite o número da segunda linha: ");
    scanf("%d", &linha2);

    somarLinhas(matriz, linha1, linha2);
    // Ou
    // multiplicarLinhas(matriz, linha1, linha2);

    printf("Matriz resultante:\n");
    for (int i = 0; i < COLUNAS; i++) {
        for (int j = 0; j < COLUNAS; j++) {
            printf("%d ", matriz[i][j]);
        }
        printf("\n");
    }

    return 0;
}
