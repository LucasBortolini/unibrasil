#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main (void) {

  int *vet[5];

  vet[0] = (int*)malloc(sizeof(int));
  vet[1] = (int*)malloc(sizeof(int));
  vet[2] = (int*)malloc(sizeof(int));
  vet[3] = (int*)malloc(sizeof(int));
  vet[4] = (int*)malloc(sizeof(int));

  *vet[0] = 1;
  *vet[1] = 2;
  *vet[2] = 3;
  *vet[3] = 4;
  *vet[4] = 5;


  printf("ptos: %d %d %d %d %d \n", *vet[0], *vet[1], *vet[2], *vet[3], *vet[4]);
  return(0);
}