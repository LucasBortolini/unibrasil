#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct 
{
    int codigo;
	char nome[20];
    char macAdress[12];
} DISPOSITIVO;

int main() 
{
    // Alocação dinâmica das estruturas
    DISPOSITIVO* dispositivo = (DISPOSITIVO*)malloc(sizeof(DISPOSITIVO));

    // Preenchimento dos dados da primeira estrutura
    printf("Digite o nome do dispositivo: ");
    scanf("%s", dispositivo->nome);
    printf("Digite a o codigo do dispositivo: ");
    scanf("%d", dispositivo->codigo);
    printf("Digite a o endereco macAdress: ");
    scanf("%s", dispositivo->macAdress);

    // Impressão dos dados das estruturas e seus endereços de memória
    printf("\nDados do dispositivo:\n");
    printf("Nome: %s\n", dispositivo->nome);
    printf("Codigo: %d\n", dispositivo->codigo);
    printf("Endereco: %d\n", dispositivo->macAdress);
    

    // Desalocação da memória alocada
    free(dispositivo);

    return 0;
}
