CREATE DATABASE bd_Ong
USE bd_Ong

CREATE TABLE tbPessoa (
  cod_pessoa INT NOT NULL,
  nome_pessoa VARCHAR(50) NOT NULL,
  fone_pessoa VARCHAR(10) NULL,
  PRIMARY KEY (cod_pessoa))

CREATE TABLE tbContato (
  nome_contato VARCHAR(50) NOT NULL,
  fone_contato VARCHAR(10) NOT NULL,
  cod_pessoa INT NOT NULL,
  PRIMARY KEY (nome_contato, cod_pessoa),
  FOREIGN KEY (cod_pessoa) REFERENCES tbPessoa (cod_pessoa))

CREATE TABLE tbArea (
  cod_area INT NOT NULL,
  nome_area VARCHAR(50) NOT NULL,
  PRIMARY KEY (cod_area))

CREATE TABLE tbEspecialidade (
  cod_especialidade INT NOT NULL,
  nome_especialidade VARCHAR(50) NOT NULL,
  cod_area INT NOT NULL,
  PRIMARY KEY (cod_especialidade),
  FOREIGN KEY (cod_area) REFERENCES tbArea (cod_area))

CREATE TABLE tbPFisica (
  CPF_pessoa VARCHAR(11) NOT NULL,
  cod_pessoa INT NOT NULL,
  PRIMARY KEY (CPF_pessoa),
  FOREIGN KEY (cod_pessoa) REFERENCES tbPessoa (cod_pessoa))

CREATE TABLE tbProjeto (
  numero_projeto INT NOT NULL,
  nome_projeto VARCHAR(50) NOT NULL,
  data_inicio DATE NOT NULL,
  data_final DATE NOT NULL, CONSTRAINT check_date CHECK (data_final > data_inicio),
  CPF_pessoa VARCHAR(11) NOT NULL,
  PRIMARY KEY (numero_projeto),
  FOREIGN KEY (CPF_pessoa)  REFERENCES tbPFisica (CPF_pessoa))

CREATE TABLE tbPJuridica (
  CNPJ_pessoa VARCHAR(13) NOT NULL,
  cod_pessoa INT NOT NULL,
  PRIMARY KEY (CNPJ_pessoa),
  FOREIGN KEY (cod_pessoa) REFERENCES tbPessoa (cod_pessoa))

CREATE TABLE tbPFisicaEspecialidade (
  CPF_pessoa VARCHAR(11) NOT NULL,
  cod_especialidade INT NOT NULL,
  PRIMARY KEY (CPF_pessoa, cod_especialidade), 
  FOREIGN KEY (CPF_pessoa) REFERENCES tbPFisica (CPF_pessoa),
  FOREIGN KEY (cod_especialidade) REFERENCES tbEspecialidade (cod_especialidade))
  
CREATE TABLE tbPFisicaProjeto (
  CPF_pessoa VARCHAR(11) NOT NULL,
  numero_projeto INT NOT NULL,
  data_inicio DATE NOT NULL,
  data_fim DATE NULL,
  CONSTRAINT check_final CHECK (data_fim > data_inicio),
  PRIMARY KEY (CPF_pessoa, numero_projeto, data_inicio),
  FOREIGN KEY (CPF_pessoa) REFERENCES tbPFisica (CPF_pessoa),
  FOREIGN KEY (numero_projeto) REFERENCES tbProjeto (numero_projeto))

CREATE TABLE tbDoacao (
  numero_doacao INT NOT NULL,
  valor_doacao REAL NOT NULL,
  data_doacao DATE NOT NULL,
  CNPJ_pessoa VARCHAR(13) NOT NULL,
  numero_projeto INT NOT NULL,
  PRIMARY KEY (numero_doacao),
  FOREIGN KEY (numero_projeto) REFERENCES tbProjeto (numero_projeto),
  FOREIGN KEY (CNPJ_pessoa) REFERENCES tbPJuridica (CNPJ_pessoa))

