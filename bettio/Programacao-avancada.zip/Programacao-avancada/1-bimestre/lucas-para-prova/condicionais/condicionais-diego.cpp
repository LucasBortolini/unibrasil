#include <stdio.h>

/*
int main(void)
{
	float nota1, nota2, media;
	
	fflush(stdin);
	printf("Entre com a nota 1\n");
	scanf("%f", &nota1);
	
	fflush(stdin);
	printf("Entre com a nota 2\n");
	scanf("%f", &nota2);
	
	media = (nota1 + nota2)/2;
	printf("A media eh: %1f\n", media);
	
	if(media > 7)
	{
		printf("Aprovado\n");
	}
	else
	{
		printf("Exame Final\n");
	}
}
*/

//Exercicios de Condicionais if /eslse

// 1) LEIA O PRE�O DE DOIS PRODUTOS E INFORME SE O PRIMERIO � MAIOR QUE O SEGUNDO;

/*

int main(void)
{
	float preco1, preco2;
	
	fflush(stdin);
	printf("Entre com o valor 1\n");
	scanf("%f", &preco1);
	
	fflush(stdin);
	printf("Entre com o valor 2\n");
	scanf("%f", &preco2);
	
	if(preco1 > preco2)
	{
		printf("Primeiro Valor eh Maior que o Segundo\n");
	}
	else if (preco1 == preco2)
	{
		printf("Os Valores Sao Iguais\n");
	}
	else
	{
		printf("Primeiro Valor eh Menor que o Segundo\n");
	}
}

*/

// 2) LEIA O PRE�O DE DOIS PRODUTOS E INFORME QUAL � O MAIOR OU SE OS DOIS S�O IGUAIS;

/*

int main(void)
{
	float preco1, preco2;
	
	fflush(stdin);
	printf("Entre com o valor 1\n");
	scanf("%f", &preco1);
	
	fflush(stdin);
	printf("Entre com o valor 2\n");
	scanf("%f", &preco2);
	
	if(preco1 > preco2)
	{
		printf("Primeiro Valor eh Maior que o Segundo\n");
	}
	else if (preco1 < preco2)
	{
		printf("Segundo Valor eh Maior que o Primeiro\n");
	}
	else
	{
		printf("Os valores sao iguais\n");
	}
}

*/

// LEIA O VALOR DA TEMPERATURA DA AGUA E INFORME SE ELA ESTA CONGELADA, ESTADO LIQUIDO, ESTADO GASOSO

/*

int main() 
{
    
	float temp;

    printf("Digite a temperatura da agua: ");
    scanf("%f", &temp);

    if(temp <= 0) 
	{
        printf("A agua esta congelada.\n");
    }
    else if(temp > 0 && temp < 100) 
	{
        printf("A agua esta em estado liquido.\n");
    }
    else 
	{
        printf("A agua esta fervendo.\n");
    }

    return 0;
}

*/

// 4) LEIA 4 NOTAS, CALCULE A M�DIA E INFORME SE O ALUNO PASSOU POR M�DIA, FICOU NO EXAME, OU REPROVOU DIRETO.

/*

int main() {
    float nota1, nota2, nota3, nota4, media;

    printf("Digite a primeira nota: ");
    scanf("%f", &nota1);

    printf("Digite a segunda nota: ");
    scanf("%f", &nota2);

    printf("Digite a terceira nota: ");
    scanf("%f", &nota3);

    printf("Digite a quarta nota: ");
    scanf("%f", &nota4);

    media = (nota1 + nota2 + nota3 + nota4) / 4;

    if(media >= 7.0) {
        printf("O aluno foi aprovado com media de %.1f\n", media);
    }
    else if(media >= 5.0 && media < 7.0) {
        printf("O aluno ficou de exame com media de %.1f\n", media);
    }
    else {
        printf("O aluno foi reprovado com media de %.1f\n", media);
    }

    return 0;
}

*/

// 5) LEIA 4 NOTAS, CALCULE A M�DIA E INFORME SE O ALUNO PASSOU POR M�DIA, FICOU NO EXAME, OU REPROVOU DIRETO.
//    SE O ALUNO FICOU NO EXAME, SOLICITE A NOTA DO EXAME E INFORME SE ELE PASSOU OU REPROVOU


int main() {
    float nota1, nota2, nota3, nota4, media, exame;

    printf("Digite a primeira nota: ");
    scanf("%f", &nota1);

    printf("Digite a segunda nota: ");
    scanf("%f", &nota2);

    printf("Digite a terceira nota: ");
    scanf("%f", &nota3);

    printf("Digite a quarta nota: ");
    scanf("%f", &nota4);

    media = (nota1 + nota2 + nota3 + nota4) / 4;

    if(media >= 7.0) 
	{
        printf("O aluno foi aprovado com media de:  %.1f\n", media);
    }
    else if(media >= 5.0 && media < 7.0) 
	{
        printf("O aluno ficou de exame com media de: %.1f\n", media);
        
        printf("Digite a Nota do Exame Final: ");
        scanf("%f", &exame);
        
        if(exame >= 7)
        {
        	printf("O aluno foi aprovado com a nota: %.1f\n", exame);
		}
		else
		{
			printf("O aluno foi reprovado com a nota: %.1f\n", exame);
		}
    }
    else 
	{
        printf("O aluno foi reprovado com media de: %.1f\n", media);
    }

    return 0;
}








