# Statistical-calculator
Calculadora operações estatísticas (média, moda, mediana, desvio padrão, variância, coeficiente de variação). Projeto criado para a disciplina de Probabilidade e Estatística.

### Dependencies
- Jframe
