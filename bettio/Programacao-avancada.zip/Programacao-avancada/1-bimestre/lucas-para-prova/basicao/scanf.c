#include <stdio.h>

int main (void) 
{
  int x;
  int y = 4;
  float salario = 3400;
  char sexo = 'M';

  fflush(stdin); // limpeza de buffer
  printf("Entre com o valor de y\n");
  scanf("%d", &y);

  fflush(stdin); // limpeza de buffer
  printf("Entre com o salario:\n");
  scanf("%f", &salario);

  fflush(stdin); // limpeza de buffer
  printf("Qual o seu sexo (F/M)\n");
  scanf("%c", &sexo);

  printf("X: %d\n", x);
  printf("O Valor de Y e: %d\n", y);
  printf("Seu salario sera de: %.2f\n", salario);
  printf("Sexo: %c\n", sexo);
  // %d     inteiro decimal
  // %f     float
  // %lf    double
  // %c     char
  // %s     string
}
