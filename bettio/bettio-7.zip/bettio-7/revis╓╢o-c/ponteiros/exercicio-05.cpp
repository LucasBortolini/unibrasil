// 5. Crie uma função em C que receba um ponteiro para um inteiro e retorne o dobro desse valor.

#include <stdio.h>

int dobro(int *num) {
    return (*num) * 2;
}

int main() {
    int valor = 5;
    printf("O dobro de %d é %d\n", valor, dobro(&valor));
    
    return 0;
}
