#include <stdio.h>
#include <string.h>

int main() {
   char nome1[50], nome2[50], temp[50];

   printf("Digite o primeiro nome: ");
   fgets(nome1, 50, stdin);

   printf("Digite o segundo nome: ");
   fgets(nome2, 50, stdin);

   if (strcmp(nome1, nome2) > 0) {
      strcpy(temp, nome1);
      strcpy(nome1, nome2);
      strcpy(nome2, temp);
   }

   printf("Os nomes em ordem alfab�tica sao: \n");
   printf("%s%s", nome1, nome2);

   return 0;
}

