#include <stdio.h>
#include <stdio.h>

void inclui() 
{
	printf("Opcao Inclui Selecionada\n");
}

void altera()
{
	printf("Opcao Altera Selecionada\n");
}

void exclui()
{
	printf("Opcao Exclui Selecionada\n");
}

void consulta()
{
	printf("Opcao Consulta Selecionada\n");
}

int main()
{
	int opcao;
	
	do 
	{
		printf("\nMENU\n");
		printf("1 - Inclui\n");
		printf("2 - Altera\n");
		printf("3 - Exclui\n");
		printf("4 - Consulta\n");
		printf("0 - Fim\n");
		
		printf("\nDigite a opcao desejada: ");
		scanf("%d", &opcao);
		
		switch (opcao)
		{
			case 0:
				printf("Encerrando o programa...\n");
				break;
			case 1:
				inclui();
				break;
			case 2:
				altera();
				break;
			case 3:
				exclui();
				break;
			case 4:
				consulta();
				break;
			default:
				printf("Opcao Invalida\n");
				break;
		}
	}	while (opcao != 0);
	return 0;
}
