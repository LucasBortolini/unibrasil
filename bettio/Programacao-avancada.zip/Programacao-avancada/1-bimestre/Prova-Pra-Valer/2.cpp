#include <stdio.h>

int main () 
{
  int vetor [20];
  int numero = 2;
  int i;

  for(int i = 0; i < 20; i++) {
    vetor [i] = numero;
    numero *= -2;

  } 

  printf("vetor preenchido com a sequencia numerica\n");
  for (int i = 0; i < 20; i++) {
    printf("%d\n", vetor[i]);
  }
}