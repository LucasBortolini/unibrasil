#include <stdio.h>
#include <conio.h>
#include <windows.h>
#include <locale.h>

// INTRODUÇÃO A ALOCAÇÃO DINÂMICA DE MEMÓRIA - EXMEMPLO 01

/*  
int main() 
{
    float *p_n1, *p_n2, *p_n3; 

    p_n1 = (float*)malloc(sizeof(float));
    p_n2 = (float*)malloc(sizeof(float));
    p_n3 = (float*)malloc(sizeof(float));

    *p_n1 = 10;
    *p_n2 = 10;
    *p_n3 = 10;

    printf("ptos:%p %p %p \n", p_n1, p_n2, p_n3); // PRINTANDO NA TELA O ENDEREÇO DE MEMÓRIA DOS PONTEIROS 

    printf("media: %2.f\n", (*p_n1 + *p_n2 + *p_n3) / 3); // PRINTANDO NA TELA A MÉDIA

    // DESALOCANDO O ESPAÇO NA MEMÓRIA.
    free(p_n1);
    free(p_n2);
    free(p_n3);

    return 0;
}
*/

// INTRODUÇÃO A ALOCAÇÃO DINÂMICA DE MEMÓRIA - EXMEMPLO 02

struct ENDERECO
{
    char rua[20];
    int num;
};

int main()
{
    setlocale(LC_ALL, "Portuguese");

    struct ENDERECO estatico; // Alocação estática / Declarando a variável estatica do tipo struct-endereco.
    struct ENDERECO *dinamico; // Alocação dinâmica / Declarando a variável dinâmica do tipo struct-endereco.

    // EXEMPLO DE ATRIBUIÇÃO DE VALORES NO MODELO ESTÁTICO.
    estatico.num = 23;
    strcpy(estatico.rua, "Rua A");
    printf("End.Estatico: %s, %d\n", estatico.rua, estatico.num);

    // EXEMPLO DE ATRIBUIÇÃO DE VALORES NO MODELO DINÂMICO.
    dinamico = (struct ENDERECO*)malloc(sizeof(struct END));
    dinamico -> num = 22;
    strcpy(dinamico -> rua, "Rua B");
    printf("End.Dinamico: %s, %d\n", dinamico -> rua, dinamico -> num);

    // DESALOCANDO O ESPAÇO NA MEMÓRIA.
    free(dinamico); 

    getch();
    return 0 ;
}