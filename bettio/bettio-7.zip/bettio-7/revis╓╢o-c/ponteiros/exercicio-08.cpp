// 8. Crie uma função em C que receba um array de inteiros e retorne a média dos valores usando ponteiros.

#include <stdio.h>

float calcularMedia(int *array, int tamanho) {
    float soma = 0;
    for (int i = 0; i < tamanho; i++) {
        soma += *(array + i); // Acessa os elementos do array usando aritmética de ponteiros
    }
    return soma / tamanho;
}

int main() {
    int array[] = {10, 20, 30, 40, 50};
    int tamanho = sizeof(array) / sizeof(array[0]);
    
    float media = calcularMedia(array, tamanho);
    printf("A média dos elementos do array é: %.2f\n", media);
    
    return 0;
}
