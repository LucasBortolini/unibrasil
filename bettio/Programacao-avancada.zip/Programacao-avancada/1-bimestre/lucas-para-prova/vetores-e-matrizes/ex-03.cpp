// Crie um vetor de 20 posições com a seguinte sequencia numérica
// 1,-1,1,-1,1,... Após o preenchimento imprima o vetor

#include <stdio.h>

int main() {
  int vetor1[20] = {1, -1, 1, -1, 1, -1, 1, -1, 1, -1, 1, -1, 1, -1, 1, -1, 1, -1, 1, -1,};
  int i;
  
  for (int i = 0; i < 20; i++) {
    printf("%d\n", vetor1[i]);
  }
}