#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <locale.h>

typedef struct {

  char nome [50];
  int idade;

} pessoa;

int main () {

  setlocale(LC_ALL, "portuguese");

  pessoa pessoa1;
  pessoa *ponteiro1;

  ponteiro1 = (pessoa*)malloc(sizeof(pessoa));

  printf("digite o nome do filho da puta: ");
  scanf("%s", pessoa1.nome);

  printf("digite a idade do filho da puta: ");
  scanf("%d", &pessoa1.idade);

  printf("DADOS DA ESTRUTURA \n");
  printf("Pessoa 1 %s, %d anos \n", pessoa1.nome, pessoa1.idade);

  printf("enderecos das variaveis \n");  
  printf("endereco de pessoa1: %p\n", &pessoa1);
  printf("endereco de ponteiro1: %p\n", &ponteiro1);

  printf("mapa da RAM \n");
  printf("endereço de alocacao de pessoa1: %p\n", ponteiro1);
  printf("endereço de alocacao de pessoa1: %p\n", &pessoa1);

  free(ponteiro1);
  return(0);
}