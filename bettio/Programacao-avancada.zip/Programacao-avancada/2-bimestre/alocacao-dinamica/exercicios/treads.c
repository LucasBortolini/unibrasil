#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>

void *cpuBoundThread(void *arg)
{
    // Tarefa CPU Bound
    int soma = 0;
    for (int i = 0; i < 100000000; i++) {
        soma += i;
    }
    printf("CPU Bound Thread: Resultado = %d\n", soma);
    pthread_exit(NULL);
}

void *ioBound(void *arg)
{
    // Tarefa IO Bound (Apenas um exemplo com um atraso de 2 segundos)
    printf("IO Bound Thread: Iniciando operação de E/S\n");
    sleep(2);
    printf("IO Bound Thread: Operação de E/S concluída\n");
    pthread_exit(NULL);
}

void *printNumber(void *arg)
{
    // Tarefa de impressão do número 3 a cada 0,5 segundo
    for (int i = 0; i < 10; i++) {
        printf("Print Thread: 3\n");
        usleep(500000);
    }
    pthread_exit(NULL);
}

void *timeThread(void *arg)
{
    // Tarefa de imprimir a hora a cada 1 segundo
    for (int i = 0; i < 10; i++) {
        time_t currentTime = time(NULL);
        printf("Time Thread: Hora atual = %s", ctime(&currentTime));
        sleep(1);
    }
    pthread_exit(NULL);
}

int main()
{
    pthread_t thread1, thread2, thread3, thread4;

    // Criação das quatro threads
    pthread_create(&thread1, NULL, cpuBoundThread, NULL);
    pthread_create(&thread2, NULL, ioBound, NULL);
    pthread_create(&thread3, NULL, printNumber, NULL);
    pthread_create(&thread4, NULL, timeThread, NULL);

    // Aguarda a finalização das threads
    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);
    pthread_join(thread3, NULL);
    pthread_join(thread4, NULL);

    return 0;
}
