#include <iostream>
using namespace std;

int main() {
  cout << "teste" << endl;
  return 0;
}