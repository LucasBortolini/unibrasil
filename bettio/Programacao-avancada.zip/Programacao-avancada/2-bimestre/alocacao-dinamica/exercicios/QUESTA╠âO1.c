QUESTÃO1
• Crie uma pequena animação que se utilize de várias Threads na tela.
• Para isso pesquisa a função gotoxy para ser usando no printf.
#include <stdio.h>
#include <stdlib.h> 
#include <pthread.h> 
#include <unistd.h>
#define NUM_THREADS 5
#define FRAMES 10
// Função executada por cada thread 
void *animate(void *thread_id) {
  int tid = *((int *)thread_id);
  for (int i = 0; i < FRAMES; i++) {
    printf("Thread %d: Frame %d\n", tid, i);
    usleep(100000); // Espera por um curto período para criar o efeito de animação
  }
  pthread_exit(NULL); 
}
int main() {
  pthread_t threads[NUM_THREADS]; int thread_ids[NUM_THREADS];
  // Criação das threads
  for (int i = 0; i < NUM_THREADS; i++) {
    thread_ids[i] = i;
    int result = pthread_create(&threads[i], NULL, animate, (void *)&thread_ids[i]);
    if (result != 0) {
      fprintf(stderr, "Erro ao criar a Thread %d\n", i); exit(1);
    } 
  } // Aguarda até que todas as threads terminem for (int i = 0; i < NUM_THREADS; i++) {
  pthread_join(threads[i], NULL);
return 0;
}
