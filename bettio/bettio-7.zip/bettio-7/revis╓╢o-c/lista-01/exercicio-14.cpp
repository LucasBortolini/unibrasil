// 14. Crie uma função capaz de multiplicar uma linha de uma matriz por um dado número. Faça o mesmo para uma coluna.

#include <stdio.h>

#define LINHAS 3
#define COLUNAS 3

void multiplicarLinha(int matriz[LINHAS][COLUNAS], int linha, int multiplicador) {
    for (int j = 0; j < COLUNAS; j++)
        matriz[linha][j] *= multiplicador;
}

void multiplicarColuna(int matriz[LINHAS][COLUNAS], int coluna, int multiplicador) {
    for (int i = 0; i < LINHAS; i++)
        matriz[i][coluna] *= multiplicador;
}

int main() {
    int matriz[LINHAS][COLUNAS], linha, coluna, multiplicador;

    printf("Digite os elementos da matriz %dx%d:\n", LINHAS, COLUNAS);
    for (int i = 0; i < LINHAS; i++) {
        for (int j = 0; j < COLUNAS; j++) {
            scanf("%d", &matriz[i][j]);
        }
    }

    printf("Digite o número da linha a ser multiplicada: ");
    scanf("%d", &linha);
    printf("Digite o número da coluna a ser multiplicada: ");
    scanf("%d", &coluna);
    printf("Digite o multiplicador: ");
    scanf("%d", &multiplicador);

    multiplicarLinha(matriz, linha, multiplicador);
    multiplicarColuna(matriz, coluna, multiplicador);

    printf("Matriz resultante:\n");
    for (int i = 0; i < LINHAS; i++) {
        for (int j = 0; j < COLUNAS; j++) {
            printf("%d ", matriz[i][j]);
        }
        printf("\n");
    }

    return 0;
}
