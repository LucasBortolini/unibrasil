#include <iostream>

using namespace std;

int main() {

  // int n = 11;

  // if (num > 5) {

  //   if (num <= 10)
  //   {
  //     cout << "número maior que que 5 e menor que 10";
  //   }
  // }

  // if ((n % 2 == 0) && (n < 20))
  // {
  //   cout << "numero par e menor que 20";
  // }

  // if ((n % 2 == 0) || (n < 20))
  // {
  //   cout << "numero par e menor que 20";
  // }

  // if (!(n % 2 == 0))
  // {
  //   cout << "numero impar";
  // }

  // bool var = 10 > 20;

  // cout << var;

  // if(var) {
  //   cout << "verdadeiro";
  // }
  // if(!var) {
  //   cout << "falso";
  // }

  bool var1 = false;
  bool var2 = true;

  if(var1 && var2) {
    cout << "verdadeiro";
  }

  return 0;
}