#include <stdio.h>
#include <string.h>
#include <stdlib.h>


// QUEST�O 04

// int main(void)
// {
// 	int i, *p;
	
// 	i = 3;
// 	p = &i;
	
// 	printf("%d\n", i);            // VALOR DA VARI�VEL i;
// 	printf("%x\n", p);           // VALOR DE P QUE CONTEM O ENDERE�O DE i
// 	printf("%x\n", &i);         // ENDERE�O DE i
// 	printf("%x\n", &p);        //  ENDERE�O DE p
	
// 	return 0;
// }

// QUEST�O 05

struct estatica
{
	char nome[50];
	int idade;
};

int main()
{
	struct estatica est;
	strcpy(est.nome, "Diego\n");
	est.idade = 30;
	
	printf("Nome %s", est.nome);
	printf("Idade %d", est.idade);
	
	printf("\nidade: %s\n", est.nome);
	printf("nome: %d\n", &est.idade);
}




