#include <stdio.h>
#include <stdlib.h>

struct NO
{
    int info;
    struct NO *proximo;
};

int main()
{
    struct NO *topo = NULL;
    struct NO *aux;

    topo = (struct NO*) malloc(sizeof(struct NO));
    topo->info = 10;
    topo->proximo = NULL;
    aux = topo;

    topo = (struct NO*) malloc(sizeof(struct NO));
    topo->info = 11;
    topo->proximo = NULL;

    topo->proximo = aux;

    return 0;
}
