#include <iostream>

using namespace std;

int main() {

  int num, fat = 1;

  cout << "digite um numero: ";
  cin >> num;

  for(int i = 1; i < num; i++){
    fat = fat * (i + 1);
  }
  cout << "fatorial: " << fat << endl;
  return 0;
}