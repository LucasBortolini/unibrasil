import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras.optimizers import Adam

# Ler o arquivo CSV com base nas colunas selecionadas do TXT
with open('colunas_carregadas.txt', 'r') as arquivo:
    colunas_usadas = arquivo.read().splitlines()

dados_treinamento = pd.read_csv('dataset/treinamento_alunos.csv', usecols=colunas_usadas)

# Tratando colunas categóricas no conjunto de dados de treinamento
categoricas = dados_treinamento.select_dtypes(include=['object']).columns
preprocessador = ColumnTransformer(transformers=[('cat', OneHotEncoder(), categoricas)], remainder='passthrough')
X_treino = preprocessador.fit_transform(dados_treinamento.drop(columns=['NU_NOTA_REDACAO']))
y_treino = dados_treinamento['NU_NOTA_REDACAO']

# Verificando e substituindo NaN nos dados de entrada
X_treino = np.nan_to_num(X_treino)
y_treino = y_treino.fillna(y_treino.mean())  # Substitui NaN no y pela média

# Construção da rede neural com 28 neurônios na camada oculta
modelo = Sequential()
modelo.add(Dense(28, activation='relu', input_shape=(X_treino.shape[1],)))
modelo.add(Dropout(0.5))
modelo.add(Dense(1, activation='linear'))

# Definindo o otimizador Adam com uma taxa de aprendizado específica
learning_rate = 0.001
otimizador = Adam(learning_rate=learning_rate)

# Compilação do modelo
modelo.compile(optimizer=otimizador, loss='mean_squared_error', metrics=['mean_squared_error'])

# Carregar os melhores pesos salvos
checkpoint_filepath = 'melhor_modelo.keras'
modelo.load_weights(checkpoint_filepath)

# Ler a nova planilha para inferência
dados_inferencia = pd.read_csv('dataset/teste_alunos.csv', usecols=colunas_usadas)

# Tratando colunas categóricas no conjunto de dados de inferência
X_inferencia = preprocessador.transform(dados_inferencia.drop(columns=['NU_NOTA_REDACAO']))

# Verificando e substituindo NaN nos dados de entrada de inferência
X_inferencia = np.nan_to_num(X_inferencia)

# Fazer previsões no novo conjunto de dados
previsoes_inferencia = modelo.predict(X_inferencia)

# Verificando e substituindo NaN nas previsões
previsoes_inferencia = np.nan_to_num(previsoes_inferencia)

# Adicionar as previsões à nova planilha
dados_inferencia['NU_NOTA_REDACAO'] = previsoes_inferencia

# Salvar a planilha com as previsões
dados_inferencia.to_csv('dataset/nova_planilha_com_previsoes.csv', index=False)

print('Previsões salvas com sucesso na nova planilha!')
