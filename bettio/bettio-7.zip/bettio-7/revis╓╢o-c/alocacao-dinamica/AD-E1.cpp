#include <stdio.h>
#include <conio.h>
#include <windows.h>
#include <locale.h>

/* 
    Aloque uma área de memória com malloc para armazenar um número inteiro. Insira nesta área de memória o número 27 e imprima.
    Incremente o numero 27 usando o ponteiro e imprima o resultado. Desaloque o endereço alocado.
*/


int main() 
{
    int *ptr = (int*)malloc(sizeof(int)); // Aloca memória para armazenar um número inteiro

    *ptr = 27; // Insere o número 27 na área de memória alocada
    printf("Numero original: %d\n", *ptr);

    (*ptr)++; // Incrementa o número usando o ponteiro
    printf("Numero incrementado: %d\n", *ptr);

    free(ptr); // Desaloca a área de memória alocada

    return 0;
}
