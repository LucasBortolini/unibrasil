#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main (void) {

  float *p_n1, *p_n2, *p_n3, *media;
  p_n1 = (float*)malloc(sizeof(float));
  p_n2 = (float*)malloc(sizeof(float));
  p_n3 = (float*)malloc(sizeof(float));

  *p_n1 = 2.0;
  *p_n2 = 4.0;
  *p_n3 = 8.0;

  printf("ptos: %p %p %p \n", (float*)p_n1, p_n2, p_n3);
  printf("media: %f\n",(*p_n1 + *p_n2 + *p_n3)/3);
  return(0);
}