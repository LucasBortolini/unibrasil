// 3.  Escreva um programa em C que multiplique duas matrizes 3x3 fornecidas pelo usu�rio e imprima o resultado.

#include <stdio.h>

int main() {
    int matrizA[3][3], matrizB[3][3], resultado[3][3];
    
    printf("Informe os valores da primeira matriz 3x3:\n");
    for(int i = 0; i < 3; i++) {
        for(int j = 0; j < 3; j++) {
            printf("Digite o valor para a posição [%d][%d]: ", i, j);
            scanf("%d", &matrizA[i][j]);
        }
    }
    
    printf("Informe os valores da segunda matriz 3x3:\n");
    for(int i = 0; i < 3; i++) {
        for(int j = 0; j < 3; j++) {
            printf("Digite o valor para a posição [%d][%d]: ", i, j);
            scanf("%d", &matrizB[i][j]);
        }
    }
    
    // Multiplicação das matrizes
    for(int i = 0; i < 3; i++) {
        for(int j = 0; j < 3; j++) {
            resultado[i][j] = 0;
            for(int k = 0; k < 3; k++) {
                resultado[i][j] += matrizA[i][k] * matrizB[k][j];
            }
        }
    }
    
    // Imprimindo o resultado da multiplicação
    printf("Resultado da multiplicação das matrizes:\n");
    for(int i = 0; i < 3; i++) {
        for(int j = 0; j < 3; j++) {
            printf("%d ", resultado[i][j]);
        }
        printf("\n");
    }
    
    return 0;
}
