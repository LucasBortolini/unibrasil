#include <stdio.h>

int main() {
    int vetor1[5], vetor2[5], resultado[5];
    char operacao;

    // Leitura do primeiro vetor
    printf("Digite 5 numeros para preencher o primeiro vetor:\n");
    for (int i = 0; i < 5; i++) {
        scanf("%d", &vetor1[i]);
    }

    // Leitura do segundo vetor
    printf("Digite 5 numeros para preencher o segundo vetor:\n");
    for (int i = 0; i < 5; i++) {
        scanf("%d", &vetor2[i]);
    }

    // Solicita a operação
    printf("Digite a operacao desejada (+,-,*,/): ");
    scanf(" %c", &operacao);

    // Realiza a operação e armazena o resultado no terceiro vetor
    for (int i = 0; i < 5; i++) {
        switch (operacao) {
            case '+':
                resultado[i] = vetor1[i] + vetor2[i];
                break;
            case '-':
                resultado[i] = vetor1[i] - vetor2[i];
                break;
            case '*':
                resultado[i] = vetor1[i] * vetor2[i];
                break;
            case '/':
                resultado[i] = vetor1[i] / vetor2[i];
                break;
            default:
                printf("Operacao invalida.\n");
                return 1;
        }
    }

    // Imprime o resultado
    printf("Resultado:\n");
    for (int i = 0; i < 5; i++) {
        printf("%d ", resultado[i]);
    }
    printf("\n");

    return 0;
}