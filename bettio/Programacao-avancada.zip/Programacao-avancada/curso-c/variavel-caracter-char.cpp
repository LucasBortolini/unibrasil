#include <iostream>

using namespace std;

int main() {

  char c1 = 'a';
  char c2 = 'b';

  cout << c1 + c2;

}