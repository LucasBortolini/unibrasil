// 5. Fazer um programa para receber um n�mero inteiro do usu�rio e determinar se este n�mero � primo ou n�o.

#include <stdio.h>

int main() {
    int num, i, primo = 1; // supomos que o número é primo
    
    printf("Digite um número inteiro: ");
    scanf("%d", &num);
    
    for (i = 2; i <= num / 2; i++) {
        if (num % i == 0) {
            primo = 0; // se for divisível por algum número além de 1 e ele mesmo, não é primo
            break;
        }
    }
    
    if (num <= 1) {
        primo = 0; // 0 e 1 não são primos
    }
    
    if (primo == 1) {
        printf("%d é um número primo.\n", num);
    } else {
        printf("%d não é um número primo.\n", num);
    }
    
    return 0;
}
