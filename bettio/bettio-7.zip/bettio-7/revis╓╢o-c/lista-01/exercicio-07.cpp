/*
7. Faça o programa que apresenta a seguinte saída, perguntando ao usuário o número máximo (no exemplo, 9). 
Este número deve ser sempre ímpar.

1 2 3 4 5 6 7 8 9
   2 3 4 5 6 7 8
      3 4 5 6 7
         4 5 6
            5   
*/

#include <stdio.h>

int main() {
    int n;

    printf("Digite um número ímpar: ");
    scanf("%d", &n);

    if (n % 2 == 0) {
        printf("Por favor, digite um número ímpar.\n");
        return 1;
    }

    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= i; j++)
            printf("%d ", i + j - 1);
        printf("\n");
        for (int k = 1; k <= i; k++)
            printf(" ");
    }

    return 0;
}
