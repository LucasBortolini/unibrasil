// 17. Faça um rotina que remova um caracter de uma string do tipo char Str[100], dada a posição do caracter.

#include <stdio.h>
#include <string.h>

void removerCaracter(char *str, int posicao) {
    int tamanho = strlen(str);

    for (int i = posicao; i < tamanho - 1; i++) {
        str[i] = str[i + 1];
    }

    str[tamanho - 1] = '\0'; // Define o novo final da string
}

int main() {
    char str[100];
    int posicao;

    printf("Digite uma string: ");
    scanf("%s", str);
    printf("Digite a posição do caracter a ser removido: ");
    scanf("%d", &posicao);

    removerCaracter(str, posicao);

    printf("String resultante: %s\n", str);

    return 0;
}
