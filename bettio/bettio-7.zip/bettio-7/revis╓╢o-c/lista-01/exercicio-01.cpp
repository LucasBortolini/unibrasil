/*
1. Escreva um programa que produza a seguinte saída na tela:

ALUNO(A)          NOTA
=========         =====
ALINE                   9.0  
MÁRIO                 DEZ
SÉRGIO               4.5    
SHIRLEY            7.0
*/

#include <stdio.h>

int main() {
    printf("ALUNO(A)  NOTA\n");
    printf("==============\n");
    printf("ALINE 9.0\n");
    printf("MÁRIO DEZ\n");
    printf("SÉRGIO 4.5\n");
    printf("SHIRLEY 7.0\n");
    return 0;
}
