// 3 - Leia o valor da temperatura da agua e informe se ela está congelada, em estado líquido ou fervendo;

#include <stdio.h>
int main(void) {

  int agua;
  
  fflush(stdin);
  printf("Entre com a temperatura da agua\n");
  scanf("%d", &agua);
  
  if(agua < 0)
  {
    printf("a agua esta congelada\n");
  }
  else if (agua == 0)
  {
    printf("a agua esta em ponto de fusao ou solidificacao\n");
  }
  else if ((agua >= 0) && (agua < 100))
  {
    printf("a agua esta liquida\n");
  }
  else if (agua == 100)
  {
    printf("a agua esta em ponto de condensacao ou vaporizacao\n");
  }
  else
  {
    printf("a agua evaporou\n");
  }
}
