import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.impute import SimpleImputer
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense

input_path_treinamento = './dados/treinamento_alunos.csv'
dados_treinamento = pd.read_csv(input_path_treinamento, sep=',', encoding='UTF-8')

input_path_teste = './dados/teste_alunos.csv'
dados_teste = pd.read_csv(input_path_teste, sep=',', encoding='UTF-8')

colunas_remover = ['TP_FAIXA_ETARIA','TP_ESTADO_CIVIL','TP_COR_RACA','TP_NACIONALIDADE','TP_ST_CONCLUSAO','TP_ANO_CONCLUIU','TP_ESCOLA','TP_ENSINO','IN_TREINEIRO','Q001',
                   'Q002','Q003','Q004','Q005','Q006','Q007','Q008','Q009','Q010','Q011','Q012','Q013','Q014','Q015','Q016','Q017','Q018','Q019','Q020','Q021','Q022','Q023',
                   'Q024','Q025','CO_MUNICIPIO_ESC', 'CO_UF_ESC', 'SG_UF_ESC','TP_DEPENDENCIA_ADM_ESC','TP_LOCALIZACAO_ESC','TP_SIT_FUNC_ESC','CO_MUNICIPIO_PROVA','CO_UF_PROVA',
                   'SG_UF_PROVA','TP_PRESENCA_CN','TP_LINGUA','TP_STATUS_REDACAO','TP_PRESENCA_CH', 'TP_PRESENCA_LC','TP_PRESENCA_MT','CO_PROVA_CN','CO_PROVA_CH','CO_PROVA_LC',
                   'CO_PROVA_MT']

dados_treinamento = dados_treinamento.drop(columns=colunas_remover)
dados_teste_filtrado = dados_teste.drop(columns=colunas_remover)

#preenche colunas vazias
colunas_para_imputar = ['NU_NOTA_MT', 'NU_NOTA_CN']
imputer = SimpleImputer(strategy='mean')
dados_treinamento[colunas_para_imputar] = imputer.fit_transform(dados_treinamento[colunas_para_imputar])
dados_teste_filtrado[colunas_para_imputar] = imputer.transform(dados_teste_filtrado[colunas_para_imputar])

#arruma dado de sexo pra ser float
dados_treinamento['TP_SEXO'] = dados_treinamento['TP_SEXO'].map({'M': 0, 'F': 1}).astype(float)
dados_teste_filtrado['TP_SEXO'] = dados_teste_filtrado['TP_SEXO'].map({'M': 0, 'F': 1}).astype(float)

coluna_nota_redacao = 'NU_NOTA_REDACAO'

scaler = MinMaxScaler()
x_treinamento = scaler.fit_transform(dados_treinamento.drop(columns=[coluna_nota_redacao]))
y_treinamento = dados_treinamento[coluna_nota_redacao].values

x_teste = scaler.transform(dados_teste_filtrado)

x_treinamento = np.reshape(x_treinamento, (x_treinamento.shape[0], 1, x_treinamento.shape[1]))
x_teste = np.reshape(x_teste, (x_teste.shape[0], 1, x_teste.shape[1]))

model = Sequential()

num_units = 50

# Add LSTM layer 
model.add(LSTM(units=num_units, return_sequences=True, input_shape=(x_treinamento.shape[1], x_treinamento.shape[2])))
model.add(LSTM(units=num_units))

# Add the output layer
model.add(Dense(1, activation='linear'))

# Compile the model
model.compile(optimizer='adam', loss='mean_squared_error')

# Train the model using your data
model.fit(x_treinamento, y_treinamento, epochs=50, batch_size=32)

notas_previstas = model.predict(x_teste)

print(notas_previstas)

# Adiciona a coluna de previsões ao DataFrame de teste
dados_teste['NU_NOTA_REDACAO_PREDITA'] = notas_previstas

# # Salva o DataFrame com as previsões
dados_teste.to_csv("resultado.csv", index=False)
