// 7. Escreva um programa em C que aloque dinamicamente memória para armazenar um array de inteiros e use ponteiros para manipulá-lo.

#include <stdio.h>
#include <stdlib.h>

int main() {
    int tamanho;
    printf("Digite o tamanho do array: ");
    scanf("%d", &tamanho);
    
    int *array = (int *)malloc(tamanho * sizeof(int)); // Alocação dinâmica de memória
    
    printf("Digite os elementos do array:\n");
    for (int i = 0; i < tamanho; i++) {
        scanf("%d", &array[i]);
    }
    
    printf("Elementos do array:\n");
    for (int i = 0; i < tamanho; i++) {
        printf("%d ", array[i]);
    }
    printf("\n");
    
    free(array); // Libera a memória alocada
    
    return 0;
}
