#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* next;
};

void insertAtBeginning(struct Node** head, int value) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = value;
    newNode->next = *head;
    *head = newNode;
}

void insertAtEnd(struct Node** head, int value) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = value;
    newNode->next = NULL;

    if (*head == NULL) {
        *head = newNode;
    } else {
        struct Node* current = *head;
        while (current->next != NULL) {
            current = current->next;
        }
        current->next = newNode;
    }
}

void removeAtBeginning(struct Node** head) {
    if (*head == NULL) {
        printf("A lista esta vazia.\n");
        return;
    }

    struct Node* temp = *head;
    *head = (*head)->next;
    free(temp);
}

void removeAtEnd(struct Node** head) {
    if (*head == NULL) {
        printf("A lista esta vazia.\n");
        return;
    }

    struct Node* current = *head;
    struct Node* previous = NULL;

    while (current->next != NULL) {
        previous = current;
        current = current->next;
    }

    if (previous == NULL) {
        *head = NULL;
    } else {
        previous->next = NULL;
    }

    free(current);
}

void printList(struct Node* head) {
    if (head == NULL) {
        printf("A lista esta vazia.\n");
        return;
    }

    printf("Valor do topo: %d\n", head->data);
    printf("Endereco e valor dos nos que compoem a lista:\n");

    struct Node* current = head;
    while (current != NULL) {
        printf("Endereco: %p | Valor: %d\n", current, current->data);
        current = current->next;
    }
}

void clearList(struct Node** head) {
    struct Node* current = *head;
    struct Node* next;

    while (current != NULL) {
        next = current->next;
        free(current);
        current = next;
    }

    *head = NULL;
}

int main() {
    struct Node* head = NULL;
    int option, value;

    do {
        printf("\nMenu de Opcoes:\n");
        printf("1. Inclusao no inicio da lista\n");
        printf("2. Inclusao no fim da lista\n");
        printf("3. Remocao do inicio da lista\n");
        printf("4. Remocao do fim da lista\n");
        printf("5. Impressao da lista\n");
        printf("6. Sair do programa\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &option);

        switch (option) {
        case 1:
            printf("Digite o valor a ser inserido no inicio da lista: ");
            scanf("%d", &value);
            insertAtBeginning(&head, value);
            printf("Valor inserido no inicio da lista com sucesso.\n");
            break;
        case 2:
            printf("Digite o valor a ser inserido no fim da lista: ");
            scanf("%d", &value);
            getchar();  // Consumir o caractere de nova linha
            insertAtEnd(&head, value);
            printf("Valor inserido no fim da lista com sucesso.\n");
            break;
            case 3:
                removeAtBeginning(&head);
                printf("Removido o elemento do inicio da lista.\n");
                break;
            case 4:
                removeAtEnd(&head);
                printf("Removido o elemento do fim da lista.\n");
                break;
            case 5:
                printList(head);
                break;
            case 6:
                clearList(&head);
                printf("Encerrando o programa.\n");
                break;
            default:
                printf("Opcao invalida. Tente novamente.\n");
                break;
            }
            } while (option != 6);

            return 0;
            }

