#include <stdio.h>

int matriz [6][6];

int main() {

  for (int i = 0; i < 6; i++) {
    for (int j = 0; j < 6; j++) {
      if(i == j) {
        matriz [i][j] = 0;
      }
      else {
        if (j < i) {
          matriz [i][j] = 0;
        }
        else {
          matriz [i][j] = -1;
        }
      }
      if (j == 0)
      {
        printf("%d\n", matriz [i][j]);
      }
      else {
        printf("%d", matriz [i][j]);
      }

    }
  }
}