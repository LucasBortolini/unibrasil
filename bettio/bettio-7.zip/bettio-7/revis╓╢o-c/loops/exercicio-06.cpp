// 6. Escreva um programa em C que solicite um n�mero N e imprima os primeiros N termos da sequ�ncia de Fibonacci.

#include <stdio.h>

int main() {
    int N, i, termo1 = 0, termo2 = 1, proximoTermo;
    
    printf("Digite o número de termos da sequência de Fibonacci: ");
    scanf("%d", &N);
    
    printf("Os primeiros %d termos da sequência de Fibonacci:\n", N);
    
    for (i = 1; i <= N; i++) {
        printf("%d, ", termo1);
        proximoTermo = termo1 + termo2;
        termo1 = termo2;
        termo2 = proximoTermo;
    }
    
    return 0;
}
