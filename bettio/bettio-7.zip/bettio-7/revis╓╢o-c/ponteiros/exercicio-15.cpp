// 15. Faça um programa em C que leia uma string do usuário e imprima-a invertida usando ponteiros.

#include <stdio.h>

void imprimirStringInvertida(char *str) {
    if (*str == '\0') return;
    imprimirStringInvertida(str + 1);
    printf("%c", *str);
}

int main() {
    char str[] = "Hello";
    printf("String original: %s\n", str);
    printf("String invertida: ");
    imprimirStringInvertida(str);
    printf("\n");
    
    return 0;
}
