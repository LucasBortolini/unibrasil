#include <stdio.h>

int main(void)
{
 char c; // Variavel c do tipo char
 char *pc; // a variável pc está declarada como char e tem o valor de pc
 // i = 'a'; // o valor da variavel i eh a
 pc = &c; // variável pc esta localizada na variável c na memória
  

 printf("%c\n", c);            // VALOR DA VARIÁVEL C;
 printf("%x\n", pc);           // VALOR DE P QUE CONTEM O ENDEREÇO DE PC
 printf("%c\n", *pc);         // 
 printf("%x\n", &pc);        //  O ENDEREÇO DE PC
  
 return 0;
}
// QUESTÃO 04

// int main(void)
// {
//  int i, *p;
  
//  i = 3;
//  p = &i;
  
//  printf("%d\n", i);            // VALOR DA VARIÁVEL i;
//  printf("%x\n", p);           // VALOR DE P QUE CONTEM O ENDEREÇO DE i
//  printf("%x\n", &i);         // ENDEREÇO DE i
//  printf("%x\n", &p);        //  ENDEREÇO DE p
  
//  return 0;
// }