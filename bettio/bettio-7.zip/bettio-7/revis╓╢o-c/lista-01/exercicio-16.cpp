// 16. Faça uma função que retorne a posição de um dado caracter dentro de uma string.

#include <stdio.h>
#include <string.h>

int encontrarCaracter(const char *str, char alvo) {
    int posicao = -1;
    int tamanho = strlen(str);

    for (int i = 0; i < tamanho; i++) {
        if (str[i] == alvo) {
            posicao = i;
            break;
        }
    }

    return posicao;
}

int main() {
    char str[100], caracter;
    int posicao;

    printf("Digite uma string: ");
    scanf("%s", str);
    printf("Digite o caracter a ser encontrado: ");
    scanf(" %c", &caracter);

    posicao = encontrarCaracter(str, caracter);

    if (posicao != -1)
        printf("O caracter '%c' foi encontrado na posição %d.\n", caracter, posicao);
    else
        printf("O caracter '%c' não foi encontrado na string.\n", caracter);

    return 0;
}
