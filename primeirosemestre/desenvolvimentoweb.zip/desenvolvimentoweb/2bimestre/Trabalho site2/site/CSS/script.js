function abrirModal() {
  let modal = document.querySelector('.modal')
  modal.style.display = 'block';
}

function fecharModal() {
  let modal = document.querySelector('.modal')
  modal.style.display = 'none';
}

function emailValido() {
  field = document.querySelector('#email');
  console.log(field)
  usuario = field.value.substring(0, field.value.indexOf("@"));
  dominio = field.value.substring(field.value.indexOf("@")+ 1, field.value.length);
  if ((usuario.length >=1) &&
    (dominio.length >=3) && 
    (usuario.search("@")==-1) && 
    (dominio.search("@")==-1) &&
    (usuario.search(" ")==-1) && 
    (dominio.search(" ")==-1) &&
    (dominio.search(".")!=-1) &&      
    (dominio.indexOf(".") >=1)&& 
    (dominio.lastIndexOf(".") < dominio.length - 1)) {
    return true
  } else {
    return false;
  }
}

function telefoneValido() {
  telefone = document.querySelector('#celular').value;
  if ((telefone.length > 8) &&
    (telefone.length <= 11)) {
    return true;
  } else {
    return false;
  }
}

function cepValido(field) {
  cep = document.querySelector('#cep').value;
  if (cep.length == 8) {
    return true;
  } else {
    return false;
  }
}

document.getElementById("form").onsubmit = function() {
  let erro = "";
  let li_e_aceito = document.querySelector('#li_e_aceito').checked;
  if (!emailValido()) { erro += "E-mail Inválido\n" }
  if (!telefoneValido()) { erro += "Telefone Inválido\n" }
  if (!cepValido()) { erro += "CEP Inválido\n" }
  if (!li_e_aceito) { erro += "Termos não aceitos" }
  if (erro != "") { alert(erro); return false; }
};