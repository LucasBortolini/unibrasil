#include <stdio.h>
#include <stdlib.h>

struct NO
{
    int info;
    struct NO *proximo;
};

void inserirInicio(struct NO **lista, int dado)
{
    struct NO *novoNo = (struct NO*) malloc(sizeof(struct NO));
    novoNo->info = dado;
    novoNo->proximo = *lista;
    *lista = novoNo;
}

void inserirFim(struct NO **lista, int dado)
{
    struct NO *novoNo = (struct NO*) malloc(sizeof(struct NO));
    novoNo->info = dado;
    novoNo->proximo = NULL;

    if (*lista == NULL)
    {
        *lista = novoNo;
    }
    else
    {
        struct NO *temp = *lista;
        while (temp->proximo != NULL)
        {
            temp = temp->proximo;
        }
        temp->proximo = novoNo;
    }
}

void imprimirLista(struct NO *lista)
{
    struct NO *temp = lista;
    while (temp != NULL)
    {
        printf("%d ", temp->info);
        temp = temp->proximo;
    }
    printf("\n");
}

int main()
{
    struct NO *lista = NULL;
    int opcao, dado;

    while (1)
    {
        printf("\nMenu de Opcoes:\n");
        printf("1. Aloca um no no inicio\n");
        printf("2. Aloca um no no fim\n");
        printf("3. Imprime todos os nos\n");
        printf("4. Sair do programa\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);

        switch (opcao)
        {
            case 1:
                printf("Digite o valor do no: ");
                scanf("%d", &dado);
                inserirInicio(&lista, dado);
                break;
            case 2:
                printf("Digite o valor do no: ");
                scanf("%d", &dado);
                inserirFim(&lista, dado);
                break;
            case 3:
                printf("Nos da lista: ");
                imprimirLista(lista);
                break;
            case 4:
                printf("Saindo do programa...\n");
                exit(0);
            default:
                printf("Opcao invalida! Tente novamente.\n");
                break;
        }
    }

    return 0;
}
