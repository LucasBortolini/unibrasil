// 18. Faça uma rotina que insira um caracter em uma string do tipo char Str[100], dada a posição do caracter.

#include <stdio.h>
#include <string.h>

void inserirCaracter(char *str, char caracter, int posicao) {
    int tamanho = strlen(str);

    for (int i = tamanho; i >= posicao; i--) {
        str[i + 1] = str[i];
    }

    str[posicao] = caracter;
}

int main() {
    char str[100], caracter;
    int posicao;

    printf("Digite uma string: ");
    scanf("%s", str);
    printf("Digite o caracter a ser inserido: ");
    scanf(" %c", &caracter);
    printf("Digite a posição em que o caracter será inserido: ");
    scanf("%d", &posicao);

    inserirCaracter(str, caracter, posicao);

    printf("String resultante: %s\n", str);

    return 0;
}
