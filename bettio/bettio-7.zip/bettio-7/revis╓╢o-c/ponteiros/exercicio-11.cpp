// 11. Implemente uma função em C que receba dois vetores de inteiros e retorne a soma dos elementos desses vetores usando ponteiros.

#include <stdio.h>

#define TAMANHO 5

int *somaVetores(int *vetor1, int *vetor2, int tamanho) {
    int *soma = (int *)malloc(tamanho * sizeof(int)); // Aloca memória para o vetor soma
    
    for (int i = 0; i < tamanho; i++) {
        *(soma + i) = *(vetor1 + i) + *(vetor2 + i); // Soma os elementos dos dois vetores
    }
    
    return soma;
}

void imprimirVetor(int *vetor, int tamanho) {
    for (int i = 0; i < tamanho; i++) {
        printf("%d ", *(vetor + i));
    }
    printf("\n");
}

int main() {
    int vetor1[TAMANHO] = {1, 2, 3, 4, 5};
    int vetor2[TAMANHO] = {6, 7, 8, 9, 10};
    
    printf("Vetor 1: ");
    imprimirVetor(vetor1, TAMANHO);
    printf("Vetor 2: ");
    imprimirVetor(vetor2, TAMANHO);
    
    int *soma = somaVetores(vetor1, vetor2, TAMANHO);
    printf("Soma dos vetores: ");
    imprimirVetor(soma, TAMANHO);
    
    free(soma); // Libera a memória alocada para o vetor soma
    
    return 0;
}


