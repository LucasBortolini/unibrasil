// Crie uma calculadora que leia 2 números e imprima o menu abaixo:
// Digite:
// 1 Para imprimir a soma dos dois números 
// 2 Para imprimir a subtração dos dois números 
// 3 Para imprimir a multiplicação dos dois números 
// 4 Para imprimir a divisão dos dois números 

// Obs. Avise o usuário sobre divisão por zero. 


#include <stdio.h>

int main(void)
{
  int opcao;
  float resultado, x, y;

  fflush(stdin);
  printf("Digite o primeiro numero: \n");
  scanf("%f", &x);

  fflush(stdin);
  printf("Digite o segundo numero: \n");
  scanf("%f", &y);
  
  printf("DIGITE UMA DAS OPCOES ABAIXO\n");
  printf("\n1 Para imprimir a soma dos dois números\n");
  printf("2 Para imprimir a subtração dos dois números\n");
  printf("3 Para imprimir a multiplicação dos dois números\n");
  printf("4 Para imprimir a divisão dos dois números\n");
  scanf("%d", &opcao);
  
  switch(opcao)
  {
  case 1:
    resultado = x + y;
    printf("Resultado da soma: %.2f\n", resultado);
    break;
    
  case 2:
    resultado = x - y;
    printf("Resultado da subtração: %.2f\n", resultado);
    break;
    
  case 3:
    resultado = x * y;
    printf("Resultado da multiplicação: %.2f\n", resultado);
    break;
  case 4:
    if (y == 0)
    {
      printf("nao e possivel dividir por 0\n");  
    }
    else
    {
      resultado = x / y;
      printf("Resultado da divisao: %.2f\n", resultado);
    }
    break;

  default:
    printf("Opcao Invalida %d\n", opcao);

  }
  
  return 0;
}
