#include <stdio.h>
#include <stdlib.h>

/*
    Crie um programa com C que aloque QUATRO estruturas como nos slides anteriores. Com nome e idade;
    Preencha os dados e imprima as duas estruturas (dados e ponteiros)
    Imprima todos os endereços das variáveis e desenha o mapa da RAM com os endereços reais. (dos ponteiros e das alocações das structs)
*/

typedef struct 
{
    char nome[50];
    int idade;
} Pessoa;

int main() 
{
    Pessoa pessoa1, pessoa2, pessoa3, pessoa4;
    Pessoa *ptr1, *ptr2, *ptr3, *ptr4;

    // Alocando memória para as estruturas
    ptr1 = (Pessoa*)malloc(sizeof(Pessoa));
    ptr2 = (Pessoa*)malloc(sizeof(Pessoa));
    ptr3 = (Pessoa*)malloc(sizeof(Pessoa));
    ptr4 = (Pessoa*)malloc(sizeof(Pessoa));

    // Preenchendo os dados da primeira estrutura
    printf("Digite o nome da primeira pessoa: ");
    scanf("%s", pessoa1.nome);
    printf("Digite a idade da primeira pessoa: ");
    scanf("%d", &pessoa1.idade);

    // Preenchendo os dados da segunda estrutura
    printf("Digite o nome da segunda pessoa: ");
    scanf("%s", pessoa2.nome);
    printf("Digite a idade da segunda pessoa: ");
    scanf("%d", &pessoa2.idade);

    // Preenchendo os dados da terceira estrutura
    printf("Digite o nome da terceira pessoa: ");
    scanf("%s", pessoa3.nome);
    printf("Digite a idade da terceira pessoa: ");
    scanf("%d", &pessoa3.idade);

    // Preenchendo os dados da quarta estrutura
    printf("Digite o nome da quarta pessoa: ");
    scanf("%s", pessoa4.nome);
    printf("Digite a idade da quarta pessoa: ");
    scanf("%d", &pessoa4.idade);

    // Imprimindo os dados das estruturas
    printf("\n=== Dados das Estruturas ===\n");
    printf("Pessoa 1: %s, %d anos\n", pessoa1.nome, pessoa1.idade);
    printf("Pessoa 2: %s, %d anos\n", pessoa2.nome, pessoa2.idade);
    printf("Pessoa 3: %s, %d anos\n", pessoa3.nome, pessoa3.idade);
    printf("Pessoa 4: %s, %d anos\n", pessoa4.nome, pessoa4.idade);

    // Imprimindo os endereços das variáveis
    printf("\n=== Endereços das Variáveis ===\n");
    printf("Endereço de pessoa1: %p\n", &pessoa1);
    printf("Endereço de pessoa2: %p\n", &pessoa2);
    printf("Endereço de pessoa3: %p\n", &pessoa3);
    printf("Endereço de pessoa4: %p\n", &pessoa4);
    printf("Endereço de ptr1: %p\n", &ptr1);
    printf("Endereço de ptr2: %p\n", &ptr2);
    printf("Endereço de ptr3: %p\n", &ptr3);
    printf("Endereço de ptr4: %p\n", &ptr4);

    // Imprimindo os endereços das alocações das structs
    printf("\n=== Mapa da RAM ===\n");
    printf("Endereço de alocação de pessoa1: %p\n", ptr1);
    printf("Endereço de alocação de pessoa2: %p\n", ptr2);
    printf("Endereço de alocação de pessoa3: %p\n", ptr3);
    printf("Endereço de alocação de pessoa4: %p\n", ptr4);

    // Liberando a memória alocada
    free(ptr1);
    free(ptr2);
    free(ptr3);
    free(ptr4);

    return 0;
}
