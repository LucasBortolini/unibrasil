#include <stdio.h>
#include <stdlib.h>

struct NO {
    int info;
    struct NO* proximo;
};

void inserirNoFim(struct NO** lista, int dado) {
    struct NO* novoNo = (struct NO*)malloc(sizeof(struct NO));
    novoNo->info = dado;
    novoNo->proximo = NULL;

    if (*lista == NULL) {
        *lista = novoNo;
    } else {
        struct NO* atual = *lista;
        while (atual->proximo != NULL) {
            atual = atual->proximo;
        }
        atual->proximo = novoNo;
    }
}

void imprimirLista(struct NO* lista) {
    struct NO* atual = lista;
    while (atual != NULL) {
        printf("%d ", atual->info);
        atual = atual->proximo;
    }
    printf("\n");
}

int main() {
    struct NO* lista = NULL;

    // Inserção dos nós no fim
    for (int i = 1; i <= 5; i++) {
        inserirNoFim(&lista, i);
    }

    printf("Lista: ");
    imprimirLista(lista);

    return 0;
}
