#include <stdio.h>

int main(void)
{
  int x = 0;
  while (x < 5)
  {
    x = x + 1; // ou x++
    printf("X:%d\n",x);
  }
}
