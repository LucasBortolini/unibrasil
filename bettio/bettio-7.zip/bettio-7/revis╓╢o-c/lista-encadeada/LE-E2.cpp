#include <stdio.h>
#include <stdlib.h>

/*
    Crie um programa em C que aloque de forma automática 5 nós com dados de 1 a 5. Use Inserção no Fim
*/

struct NO
{
    int info;
    struct NO *proximo;
};

void inserirFinal(struct NO **lista, int dado)
{
    struct NO *novoNo = (struct NO*) malloc(sizeof(struct NO));
    novoNo->info = dado;
    novoNo->proximo = NULL;

    if (*lista == NULL)
    {
        *lista = novoNo;
    }
    else
    {
        struct NO *temp = *lista;
        while (temp->proximo != NULL)
        {
            temp = temp->proximo;
        }
        temp->proximo = novoNo;
    }
}

void exibirLista(struct NO *lista)
{
    struct NO *temp = lista;
    while (temp != NULL)
    {
        printf("%d ", temp->info);
        temp = temp->proximo;
    }
    printf("\n");
}

int main()
{
    struct NO *lista = NULL;
    int i;

    for (i = 1; i <= 5; i++)
    {
        inserirFinal(&lista, i);
    }

    printf("Lista encadeada: ");
    exibirLista(lista);

    return 0;
}
