#include <stdio.h>
#include <stdlib.h>

/*
    Crie um programa em C com um menu de opções:
    Opção 1: Aloca um nó no início;
    Opção 2: Aloca um nó no fim;
    Opção 3: Imprime todos os nós;
    Opção 4: Localiza um nó e imprime;
    Opção 5: Sai do programa.

*/

struct NO
{
    int info;
    struct NO *proximo;
};

void inserirInicio(struct NO **lista, int dado)
{
    struct NO *novoNo = (struct NO*) malloc(sizeof(struct NO));
    novoNo->info = dado;
    novoNo->proximo = *lista;
    *lista = novoNo;
}

void inserirFim(struct NO **lista, int dado)
{
    struct NO *novoNo = (struct NO*) malloc(sizeof(struct NO));
    novoNo->info = dado;
    novoNo->proximo = NULL;

    if (*lista == NULL)
    {
        *lista = novoNo;
    }
    else
    {
        struct NO *temp = *lista;
        while (temp->proximo != NULL)
        {
            temp = temp->proximo;
        }
        temp->proximo = novoNo;
    }
}

void imprimirLista(struct NO *lista)
{
    struct NO *temp = lista;
    while (temp != NULL)
    {
        printf("%d ", temp->info);
        temp = temp->proximo;
    }
    printf("\n");
}

void localizarNo(struct NO *lista, int chave)
{
    struct NO *temp = lista;
    int encontrado = 0;

    while (temp != NULL)
    {
        if (temp->info == chave)
        {
            printf("No encontrado: %d\n", temp->info);
            encontrado = 1;
        }
        temp = temp->proximo;
    }

    if (!encontrado)
    {
        printf("No nao encontrado na lista.\n");
    }
}

int main()
{
    struct NO *lista = NULL;
    int opcao, dado, chave;

    while (1)
    {
        printf("\nMenu de Opcoes:\n");
        printf("1. Aloca um no no inicio\n");
        printf("2. Aloca um no no fim\n");
        printf("3. Imprime todos os nos\n");
        printf("4. Localiza um no e imprime\n");
        printf("5. Sair do programa\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);

        switch (opcao)
        {
            case 1:
                printf("Digite o valor do no: ");
                scanf("%d", &dado);
                inserirInicio(&lista, dado);
                break;
            case 2:
                printf("Digite o valor do no: ");
                scanf("%d", &dado);
                inserirFim(&lista, dado);
                break;
            case 3:
                printf("Nos da lista: ");
                imprimirLista(lista);
                break;
            case 4:
                printf("Digite o valor do no a ser localizado: ");
                scanf("%d", &chave);
                localizarNo(lista, chave);
                break;
            case 5:
                printf("Saindo do programa...\n");
                exit(0);
            default:
                printf("Opcao invalida! Tente novamente.\n");
                break;
        }
    }

    return 0;
}
