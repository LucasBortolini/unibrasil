// 1) Crie um menu com 4 opções usando o switch case
// Opção 1 imprimirá Bom dia; Opção 2 Boa Tarde; Opção 3 Boa Noite; Opção 4 Até Mais.

#include <stdio.h>

int main(void)
{
  int opcao;
  
  printf("DIGITE UMA DAS OPCOES ABAIXO \n");
  printf("\nOpcao 1: Bom Dia \n");
  printf("Opcao 2: Boa Tarde \n");
  printf("Opcao 3: Boa Noite \n");
  printf("Opcao 4: Ate Mais \n");
  scanf("%d", &opcao);
  
  switch(opcao)
  {
    case 1:
      printf("O Usuario escolheu a opcao %d: Bom Dia\n", opcao);
    break;
    
    case 2:
      printf("O Usuario escolheu a opcao %d: Boa Tarde\n", opcao);
    break;
    
    case 3:
      printf("O Usuario escolheu a opcao %d: Boa Noite\n", opcao);
    break;
    case 4:
      printf("O Usuario escolheu a opcao %d: Ate Mais\n", opcao);
    break;
    default:
      printf("Opcao Invalida %d", opcao);
      
  }
  
  return 0;
}
