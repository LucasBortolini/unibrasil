// 1.  Crie um programa em C que declare um vetor de 5 elementos e preencha-o com valores aleat�rios.

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define TAMANHO_VETOR 5

int main() {
    int vetor[TAMANHO_VETOR];
    int i;

    // Inicializa o gerador de números aleatórios com o tempo atual
    srand(time(NULL));

    // Preenche o vetor com valores aleatórios
    for (i = 0; i < TAMANHO_VETOR; i++) {
        vetor[i] = rand() % 100; // Gera valores aleatórios entre 0 e 99
    }

    // Imprime o vetor preenchido
    printf("Vetor preenchido com valores aleatórios:\n");
    for (i = 0; i < TAMANHO_VETOR; i++) {
        printf("%d ", vetor[i]);
    }
    printf("\n");

    return 0;
}
