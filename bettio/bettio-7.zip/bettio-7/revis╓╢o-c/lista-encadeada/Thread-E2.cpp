#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>
#include <conio.h>

void gotoxy(int x, int y);
void printClock();

int main()
{
    char nome[100];
    char endereco[100];

    // Limpa a tela
    system("cls");

    printf("=== Cadastro de Cliente ===\n");

    printf("Digite o nome: ");
    fgets(nome, sizeof(nome), stdin);

    printf("Digite o endereco: ");
    fgets(endereco, sizeof(endereco), stdin);

    // Limpa a tela
    system("cls");

    printf("=== Dados do Cliente ===\n");
    printf("Nome: %s", nome);
    printf("Endereco: %s", endereco);

    printf("\n\n");

    printf("=== Relogio em Tempo Real ===\n");

    // Loop infinito para atualizar o relógio a cada segundo
    while (1)
    {
        printClock();
        Sleep(1000);
    }

    return 0;
}

void gotoxy(int x, int y)
{
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

void printClock()
{
    time_t currentTime;
    struct tm* timeInfo;
    char timeString[9];  // HH:MM:SS\0

    // Obtém o tempo atual
    time(&currentTime);
    timeInfo = localtime(&currentTime);

    // Formata a hora atual como uma string HH:MM:SS
    strftime(timeString, sizeof(timeString), "%H:%M:%S", timeInfo);

    // Posiciona o cursor na base do monitor e imprime o relógio
    gotoxy(0, GetSystemMetrics(SM_CYSCREEN) - 1);
    printf("Relogio: %s", timeString);
}
