// 4. Escreva um programa em C que ordene um vetor de inteiros em ordem crescente.

#include <stdio.h>

#define TAMANHO_VETOR 5

void ordenarVetor(int vetor[], int tamanho) {
    int i, j, temp;

    for (i = 0; i < tamanho - 1; i++) {
        for (j = 0; j < tamanho - i - 1; j++) {
            if (vetor[j] > vetor[j + 1]) {
                temp = vetor[j];
                vetor[j] = vetor[j + 1];
                vetor[j + 1] = temp;
            }
        }
    }
}

int main() {
    int vetor[TAMANHO_VETOR];
    int i;

    printf("Digite %d números para preencher o vetor:\n", TAMANHO_VETOR);
    for (i = 0; i < TAMANHO_VETOR; i++) {
        scanf("%d", &vetor[i]);
    }

    printf("Vetor antes da ordenação:\n");
    for (i = 0; i < TAMANHO_VETOR; i++) {
        printf("%d ", vetor[i]);
    }
    printf("\n");

    ordenarVetor(vetor, TAMANHO_VETOR);

    printf("Vetor após a ordenação:\n");
    for (i = 0; i < TAMANHO_VETOR; i++) {
        printf("%d ", vetor[i]);
    }
    printf("\n");

    return 0;
}
