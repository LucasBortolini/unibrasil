// 2 - Leia o preço de dois produtos e informe qual é maior ou se os dois são iguais;


#include <stdio.h>
int main(void) {

  float preco1, preco2;
  
  fflush(stdin);
  printf("Entre com o valor 1\n");
  scanf("%f", &preco1);
  
  fflush(stdin);
  printf("Entre com o valor 2\n");
  scanf("%f", &preco2);
  
  if(preco1 > preco2)
  {
    printf("Primeiro Valor eh Maior que o Segundo\n");
  }
  else if (preco1 == preco2)
  {
    printf("Os Valores Sao Iguais\n");
  }
  else
  {
    printf("Primeiro Valor eh Menor que o Segundo\n");
  }
}