// 6 - Pesquise na internet qual a faixa salarial das classes sociais A, B, C e D,
// solicite ao usuário informar o seu salário e informe em qual classe ele esta;

#include <stdio.h>

int main(void) {

  float salario;
  
  fflush(stdin);
  printf("digite o seu salario\n");
  scanf("%f", &salario);
  
  if(salario >= 22000)
  {
    printf("Voce eh da classe A (Y)\n");
  }
  else if (salario > 7099)
  {
    printf("Voce eh da classe B (Y)\n");
  }
  else if (salario > 2899)
  {
    printf("Voce eh da classe C (Y)\n");
  }
  else
  {
    printf("Voce eh da classe D (Y)\n"); 
  }
}  

