#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
    1) Crie duas structs, uma estática e outra dinâmica com os seguintes campos:

    Quantidade;
    Descrição do produto;
    Valor Unitário

    2) Preencha a struct estática com scanf;
    
    3) Aloque a struct dinâmica. Copie os dados da struct estática para a dinâmica;
    
    4) Imprima a struct dinâmica.

*/

struct Produto 
{
    int quantidade;
    char descricao[100];
    float valorUnitario;
};

int main() 
{   
    // Modelo de struct ESTÁTICO
    struct Produto produtoEstatico;
    printf("Digite a quantidade: ");
    scanf("%d", &produtoEstatico.quantidade);

    printf("Digite a descricao: ");
    scanf(" %[^\n]s", produtoEstatico.descricao);

    printf("Digite o valor unitario: ");
    scanf("%f", &produtoEstatico.valorUnitario);

    // Modelo de struct DINÂMICO
    struct Produto* produtoDinamico = (struct Produto*)malloc(sizeof(struct Produto));
    *produtoDinamico = produtoEstatico; // INSERINDO OS DADOS DA STRUCT ESTÁTICA NA STRUCT DINÂMICA.

    // Mostrando as informações inseridas na tela.
    printf("\nStruct dinâmica:\n");
    printf("Quantidade: %d\n", produtoDinamico->quantidade);
    printf("Descricao: %s\n", produtoDinamico->descricao);
    printf("Valor Unitario: %.2f\n", produtoDinamico->valorUnitario);

    // Desalocando Memória.
    free(produtoDinamico);

    return 0;
}
