#include <stdio.h>
#include <stdlib.h>

/*
    Crie um programa com C que aloque DUAS estruturas como nos slides anteriores. Com nome e idade;
    Preencha os dados e imprima as duas estruturas (dados e ponteiros)
    Imprima todos os endereços das variáveis e desenha o mapa da RAM com os endereços reais. (dos ponteiros e das alocações das structs)
*/


typedef struct 
{
    char nome[50];
    int idade;
} Pessoa;

int main() 
{
    // Alocação dinâmica das estruturas
    Pessoa* pessoa1 = (Pessoa*)malloc(sizeof(Pessoa));

    // Preenchimento dos dados da primeira estrutura
    printf("Digite o nome da pessoa 1: ");
    scanf("%s", pessoa1->nome);
    printf("Digite a idade da pessoa 1: ");
    scanf("%d", &pessoa1->idade);

    // Impressão dos dados das estruturas e seus endereços de memória
    printf("\nDados da Pessoa 1:\n");
    printf("Nome: %s\n", pessoa1->nome);
    printf("Idade: %d\n", pessoa1->idade);
    printf("Endereço da estrutura: %p\n", pessoa1);
    printf("Endereço do nome: %p\n", pessoa1->nome);
    printf("Endereço da idade: %p\n", pessoa1->idade);

    // Desalocação da memória alocada
    free(pessoa1);

    return 0;
}
