#include <stdio.h>
#include <stdlib.h>

/*
    Crie um programa em C que aloque de forma automática 5 nós com dados de 1 a 5. Use Inserção no Início
*/

struct NO
{
    int info;
    struct NO *proximo;
};

void inserirInicio(struct NO **lista, int dado)
{
    struct NO *novoNo = (struct NO*) malloc(sizeof(struct NO));
    novoNo->info = dado;
    novoNo->proximo = *lista;
    *lista = novoNo;
}

void exibirLista(struct NO *lista)
{
    struct NO *temp = lista;
    while (temp != NULL)
    {
        printf("%d ", temp->info);
        temp = temp->proximo;
    }
    printf("\n");
}

int main()
{
    struct NO *lista = NULL;
    int i;

    for (i = 5; i >= 1; i--)
    {
        inserirInicio(&lista, i);
    }
    
    printf("Lista encadeada: ");
    exibirLista(lista);

    return 0;
}