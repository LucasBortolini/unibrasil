// 2. Crie uma função em C que troque os valores de duas variáveis inteiras usando ponteiros.

#include <stdio.h>

void trocar(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

int main() {
    int x = 5, y = 10;
    printf("Valores originais: x = %d, y = %d\n", x, y);
    
    trocar(&x, &y); // Chamada da função para trocar os valores
    printf("Valores trocados: x = %d, y = %d\n", x, y);
    
    return 0;
}
