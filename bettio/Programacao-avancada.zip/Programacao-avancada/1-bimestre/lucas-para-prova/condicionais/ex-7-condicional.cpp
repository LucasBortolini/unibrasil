// 7 - Solicite ao usuário, seu peso, sua altura e calcule o IMC 
// informando em qual faixa ele se encontra.

// dividindo o peso (em kg) pela altura ao quadrado (em metros)

#include <stdio.h>

int main(void) {

  float peso, altura;
  
  fflush(stdin);
  printf("digite o seu peso em kg\n");
  scanf("%f", &peso);

  fflush(stdin);
  printf("digite a sua altura em metros\n");
  scanf("%f", &altura);

  float imc = (peso / (altura * altura));
  
  if(imc > 40)
  {
    printf("Voce esta obeso nivel III, procure um medico! seu imc esta:%.1f\n", imc);
  }
  else if(imc >= 30)
  {
    printf("Voce esta obeso nivel II, procure um medico! seu imc esta:%.1f\n", imc);
  }
  else if(imc >= 25)
  {
    printf("Voce esta com sobrepeso nivel I. Vai malhar, puta! seu imc esta:%.1f\n", imc);
  }
  else if(imc >= 18.5)
  {
    printf("seu imc esta normal! seu imc esta:%.1f\n", imc);
  }
  else
  {
    printf("tu eh magro ein, tio! seu imc esta:%.1f\n", imc);
  }
}  

