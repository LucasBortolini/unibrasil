#include <stdio.h>

// 1) FA�A UM PROGRAMA EM C QUE REALIZE UMA CONTAGEM DECRESCENTE DE 99 A 0 UTILIZANDO O FOR.

/*
int main(void)
{
	int contador; // Vari�vel de Controle de loop
	
	for(contador = 99; contador >=0; contador--)
	{
		printf("%d \n", contador);
	}
	
	return(0);
}
*/

// 2) FA�A UM PROGRAMA EM C QUE REALIZE UMA CONTAGEM DECRESCENTE DE 99 A 0 UTILIZANDO O WHILE.


int main(void)
{
	int contador = 99;
	
	while(contador >= 0)
	{
		printf("%d \n", contador);
		
		contador--;
	}
	
	return 0;
}
