#include <iostream>

using namespace std;

int main() {

  // int num = 10;

  // switch(num) {
  //   case 9:
  //     cout << "numero 9";
  //     break;
  //   case 10:
  //     cout << "numero 10";
  //     break;
  //   case 11:
  //     cout << "numero 11";
  //     break;
  //   default:
  //     cout << "numero não encontrado";


  // }

  int num1, num2, resultado;
  float div;
  char op;

  cout << "digite o primeiro numero: ";
  cin >> num1;
  cout << "digite o segundo numero: ";
  cin >> num2;
  cout << "digite a operacao: ";
  cin >> op;

  switch(op) {
    case '+':
      resultado = num1 + num2;
      cout << "soma: " << resultado << endl;
      break;
    case '-':
      resultado = num1 - num2;
      cout << "subtracao: " << resultado << endl;
      break;
    case '/':
      if(num2 != 0) {
      div = (float)num1 / num2;
      cout << "divisao: " << div << endl;      
      } else {
        cout << "divisao por 0!!" << endl;
      }
      break;
    case '*':
      resultado = num1 * num2;
      cout << "multiplicacao: " << resultado << endl;
      break;
    default:
      cout << "operacao inexistente" << endl;
  }
  return 0;
}