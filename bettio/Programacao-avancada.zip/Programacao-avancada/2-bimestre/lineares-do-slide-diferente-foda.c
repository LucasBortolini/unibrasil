#include <stdio.h>
#include <stdlib.h>

struct No {
    int data;
    struct No* next;
};

void InsereNoComeco(struct No** head, int value) {
    struct No* NovoNo = (struct No*)malloc(sizeof(struct No));
    NovoNo->data = value;
    NovoNo->next = *head;
    *head = NovoNo;
}

void InsereNoFim(struct No** head, int value) {
    struct No* NovoNo = (struct No*)malloc(sizeof(struct No));
    NovoNo->data = value;
    NovoNo->next = NULL;

    if (*head == NULL) {
        *head = NovoNo;
    } else {
        struct No* current = *head;
        while (current->next != NULL) {
            current = current->next;
        }
        current->next = NovoNo;
    }
}

void removeNoComeco(struct No** head) {
    if (*head == NULL) {
        printf("A lista esta vazia.\n");
        return;
    }

    struct No* temp = *head;
    *head = (*head)->next;
    free(temp);
}

void RemoveNoFim(struct No** head) {
    if (*head == NULL) {
        printf("A lista esta vazia.\n");
        return;
    }

    struct No* current = *head;
    struct No* previous = NULL;

    while (current->next != NULL) {
        previous = current;
        current = current->next;
    }

    if (previous == NULL) {
        *head = NULL;
    } else {
        previous->next = NULL;
    }

    free(current);
}

void printList(struct No* head) {
    if (head == NULL) {
        printf("A lista esta vazia.\n");
        return;
    }

    printf("Valor do topo: %d\n", head->data);
    printf("Endereco e valor dos nos que compoem a lista:\n");

    struct No* current = head;
    while (current != NULL) {
        printf("Endereco: %p | Valor: %d\n", current, current->data);
        current = current->next;
    }
}

void LimpaLista(struct No** head) {
    struct No* current = *head;
    struct No* next;

    while (current != NULL) {
        next = current->next;
        free(current);
        current = next;
    }

    *head = NULL;
}

int main() {
    struct No* head = NULL;
    int option, value;

    do {
        printf("\nMenu de Opcoes:\n");
        printf("1. Inclusao no inicio da lista\n");
        printf("2. Inclusao no fim da lista\n");
        printf("3. Remocao do inicio da lista\n");
        printf("4. Remocao do fim da lista\n");
        printf("5. Impressao da lista\n");
        printf("6. Sair do programa\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &option);

        switch (option) {
            case 1:
                printf("Digite o valor a ser inserido no inicio da lista: ");
                scanf("%d", &value);
                InsereNoComeco(&head, value);
                printf("Valor inserido no inicio da lista com sucesso.\n");
                break;
            case 2:
                printf("Digite o valor a ser inserido no fim da lista: ");
                scanf("%d", &value);
                InsereNoFim(&head, value);
                printf("Valor inserido no fim da lista com sucesso.\n");
                break;
            case 3:
                removeNoComeco(&head);
                printf("Removido o elemento do inicio da lista.\n");
                break;
            case 4:
                RemoveNoFim(&head);
                printf("Removido o elemento do fim da lista.\n");
                break;
            case 5:
                printList(head);
                break;
            case 6:
                LimpaLista(&head);
                printf("Encerrando o programa.\n");
                break;
            default:
                printf("Opcao invalida. Tente novamente.\n");
                break;
        }
    } while (option != 6);

    return 0;
}
