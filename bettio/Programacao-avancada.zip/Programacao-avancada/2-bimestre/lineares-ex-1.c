#include <stdio.h>
#include <stdlib.h>

struct NO {
    int info;
    struct NO* proximo;
};

void inserirNoInicio(struct NO** lista, int dado) {
    struct NO* novoNo = (struct NO*)malloc(sizeof(struct NO));
    novoNo->info = dado;
    novoNo->proximo = *lista;
    *lista = novoNo;
}

void imprimirLista(struct NO* lista) {
    struct NO* atual = lista;
    while (atual != NULL) {
        printf("%d ", atual->info);
        atual = atual->proximo;
    }
    printf("\n");
}

int main() {
    struct NO* lista = NULL;

    // Inserção dos nós no início
    for (int i = 5; i >= 1; i--) {
        inserirNoInicio(&lista, i);
    }

    printf("Lista: ");
    imprimirLista(lista);

    return 0;
}