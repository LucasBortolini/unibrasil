#include <stdio.h>

struct Pessoa {
    char endereco[50];
    int cep;
};

int main() {
    struct Pessoa pessoa;

    printf("Digite seu endereco: ");
    scanf("%s", pessoa.endereco);

    printf("Digite seu cep: ");
    scanf("%d", &pessoa.cep);

    printf("\nConteúdo da estrutura:\n");
    printf("endereco: %s\ncep: %d\n", pessoa.endereco, pessoa.cep);

    printf("\nMapa de memória:\n");
    printf("Endereço do nome: %x\n", (void*)&pessoa.endereco);
    printf("Endereço da idade: %x\n", (void*)&pessoa.cep);

    return 0;
}