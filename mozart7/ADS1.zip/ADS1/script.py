import pandas as pd
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error
from sklearn.impute import SimpleImputer

# Carregar dados de treinamento
input_path_treinamento = './treinamento_alunos.csv'
dados_treinamento = pd.read_csv(input_path_treinamento, sep=',', encoding='UTF-8')

# Carregar dados de teste
input_path_teste = './teste_alunos.csv'
dados_teste = pd.read_csv(input_path_teste, sep=',', encoding='UTF-8')

# remover colunas não utilizadas
dados_treinamento = dados_treinamento.drop(columns=['TP_FAIXA_ETARIA','TP_ESTADO_CIVIL','TP_COR_RACA','TP_NACIONALIDADE','TP_ST_CONCLUSAO','TP_ANO_CONCLUIU','TP_ESCOLA','TP_ENSINO','IN_TREINEIRO','Q001',
                           'Q002','Q003','Q004','Q005','Q006','Q007','Q008','Q009','Q010','Q011','Q012','Q013','Q014','Q015','Q016','Q017','Q018','Q019','Q020','Q021','Q022','Q023',
                           'Q024','Q025','CO_MUNICIPIO_ESC', 'CO_UF_ESC', 'SG_UF_ESC','TP_DEPENDENCIA_ADM_ESC','TP_LOCALIZACAO_ESC','TP_SIT_FUNC_ESC','CO_MUNICIPIO_PROVA','CO_UF_PROVA','SG_UF_PROVA','TP_PRESENCA_CN','TP_LINGUA','TP_STATUS_REDACAO','TP_PRESENCA_CH', 'TP_PRESENCA_LC','TP_PRESENCA_MT','CO_PROVA_CN','CO_PROVA_CH','CO_PROVA_LC','CO_PROVA_MT'])

dados_teste_filtratos = dados_teste.drop(columns=['TP_FAIXA_ETARIA','TP_ESTADO_CIVIL','TP_COR_RACA','TP_NACIONALIDADE','TP_ST_CONCLUSAO','TP_ANO_CONCLUIU','TP_ESCOLA','TP_ENSINO','IN_TREINEIRO','Q001',
                           'Q002','Q003','Q004','Q005','Q006','Q007','Q008','Q009','Q010','Q011','Q012','Q013','Q014','Q015','Q016','Q017','Q018','Q019','Q020','Q021','Q022','Q023',
                           'Q024','Q025','CO_MUNICIPIO_ESC', 'CO_UF_ESC', 'SG_UF_ESC','TP_DEPENDENCIA_ADM_ESC','TP_LOCALIZACAO_ESC','TP_SIT_FUNC_ESC','CO_MUNICIPIO_PROVA','CO_UF_PROVA','SG_UF_PROVA','TP_PRESENCA_CN','TP_LINGUA','TP_STATUS_REDACAO','TP_PRESENCA_CH', 'TP_PRESENCA_LC','TP_PRESENCA_MT','CO_PROVA_CN','CO_PROVA_CH','CO_PROVA_LC','CO_PROVA_MT'])

# preencher valores ausentes
colunas_para_imputar = ['NU_NOTA_CN', 'NU_NOTA_MT']
imputer = SimpleImputer(strategy='mean')
dados_treinamento[colunas_para_imputar] = imputer.fit_transform(dados_treinamento[colunas_para_imputar])
dados_teste_filtratos[colunas_para_imputar] = imputer.transform(dados_teste_filtratos[colunas_para_imputar])

# converter coluna TP_SEXO para numérico
dados_treinamento['TP_SEXO'] = dados_treinamento['TP_SEXO'].map({'M': 0, 'F': 1}).astype(float)
dados_teste_filtratos['TP_SEXO'] = dados_teste_filtratos['TP_SEXO'].map({'M': 0, 'F': 1}).astype(float)

# Dividir os dados em features (x) e alvo (y) para treinamento e teste
x_treinamento = dados_treinamento.drop(columns=["Original_NU_NOTA_REDACAO"])
y_treinamento = dados_treinamento["Original_NU_NOTA_REDACAO"]

# Treinar o modelo SVR
model = SVR(kernel='linear')
model.fit(x_treinamento, y_treinamento)

# Fazer previsões nos dados de teste
notas_previstas = model.predict(dados_teste_filtratos)

# Adicionar previsões como uma nova coluna aos dados de teste
dados_teste['NU_NOTA_REDACAO_PREDITA'] = notas_previstas

# Salvar os dados de teste com as previsões
dados_teste.to_csv("teste_alunos_resultado.csv")
