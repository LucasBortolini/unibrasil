#include <stdio.h>
#include <stdlib.h>

/*
    Crie um programa em C que preencha 5 structs CADASTRO com nome e telefone usando scanf, cada endereço retornado pelo malloc será armazenado em um vetor de ponteiros.
    struct CADASTRO *vet[5];
*/
struct CADASTRO 
{
    char nome[50];
    char telefone[15];
};

int main() 
{
    struct CADASTRO *vet[5];

    for (int i = 0; i < 5; i++) 
    {
        vet[i] = (struct CADASTRO*)malloc(sizeof(struct CADASTRO));

        printf("Digite o nome: ");
        scanf(" %[^\n]s", vet[i]->nome);

        printf("Digite o telefone: ");
        scanf(" %[^\n]s", vet[i]->telefone);
    }

    printf("\nDados cadastrados:\n");

    for (int i = 0; i < 5; i++) 
    {
        printf("Cadastro %d:\n", i + 1);
        printf("Nome: %s\n", vet[i]->nome);
        printf("Telefone: %s\n", vet[i]->telefone);
        printf("\n");
    }

    for (int i = 0; i < 5; i++) 
    {
        free(vet[i]);
    }

    return 0;
}
