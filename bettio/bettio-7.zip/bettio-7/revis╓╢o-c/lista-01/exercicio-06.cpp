/*
6. Escreva um programa que leia 3 notas de um aluno e a média das notas dos exercícios realizados por ele. 
Calcular a média de aproveitamento, usando a fórmula: MA = (N1 + N2*2 + N3*3 + ME)/7. A partir da média, 
informar o conceito de acordo com a tabela:

maior ou igual a 9	A
maior ou igual a 7.5 e menor que 9	B
maior ou igual a 6 e menor que 7.5	C
maior ou igual a 4 e menor que 6	D
menor que 4	E
*/
#include <stdio.h>

int main() {
    float N1, N2, N3, ME, MA;
    char conceito;

    printf("Digite as três notas do aluno: ");
    scanf("%f %f %f", &N1, &N2, &N3);
    printf("Digite a média dos exercícios: ");
    scanf("%f", &ME);

    MA = (N1 + N2 * 2 + N3 * 3 + ME) / 7;

    if (MA >= 9)
        conceito = 'A';
    else if (MA >= 7.5)
        conceito = 'B';
    else if (MA >= 6)
        conceito = 'C';
    else if (MA >= 4)
        conceito = 'D';
    else
        conceito = 'E';

    printf("Média de aproveitamento: %.2f\n", MA);
    printf("Conceito: %c\n", conceito);

    return 0;
}
