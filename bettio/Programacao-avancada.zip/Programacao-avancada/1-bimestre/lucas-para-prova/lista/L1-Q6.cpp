#include <stdio.h>

int main() {
    float nota1, nota2, nota3, media_exercicios, media_aproveitamento;
    char conceito;
    
    printf("Informe a primeira nota: ");
    scanf("%f", &nota1);
    
    printf("Informe a segunda nota: ");
    scanf("%f", &nota2);
    
    printf("Informe a terceira nota: ");
    scanf("%f", &nota3);
    
    printf("Informe a media dos exercicios: ");
    scanf("%f", &media_exercicios);
    
    media_aproveitamento = (nota1 + nota2*2 + nota3*3 + media_exercicios) / 7.0;
    
    if (media_aproveitamento >= 9.0) {
        conceito = 'A';
    } else if (media_aproveitamento >= 7.5) {
        conceito = 'B';
    } else if (media_aproveitamento >= 6.0) {
        conceito = 'C';
    } else if (media_aproveitamento >= 4.0) {
        conceito = 'D';
    } else {
        conceito = 'E';
    }
    
    printf("Media de aproveitamento: %.2f\n", media_aproveitamento);
    printf("Conceito: %c", conceito);
    
    return 0;
}

