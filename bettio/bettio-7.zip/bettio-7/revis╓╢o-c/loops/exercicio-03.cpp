// 3.  Escreva um programa em C que solicite um n�mero inteiro positivo N e imprima os n�meros de 1 a N.

#include <stdio.h>

int main() {
    int N, i;
    
    printf("Digite um número inteiro positivo: ");
    scanf("%d", &N);
    
    printf("Números de 1 a %d:\n", N);
    for (i = 1; i <= N; i++) {
        printf("%d ", i);
    }
    
    return 0;
}
