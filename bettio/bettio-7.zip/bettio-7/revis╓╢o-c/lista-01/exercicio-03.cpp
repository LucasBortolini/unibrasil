/*
3. Menu - Elabore um programa que mostre o seguinte menu na tela:
Cadastro de Clientes
0 - Fim
1 - Inclui
2 - Altera
3 - Exclui
4 - Consulta
Opção: 
*/

#include <stdio.h>

int main() {
    printf("Cadastro de Clientes\n");
    printf("0 - Fim\n");
    printf("1 - Inclui\n");
    printf("2 - Altera\n");
    printf("3 - Exclui\n");
    printf("4 - Consulta\n");
    printf("Opção: ");
    return 0;
}
