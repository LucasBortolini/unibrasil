#include <stdio.h>

// 1) Crie um menu com 4 op��es usando o switch case
//    Op��o 1 imprimir� Bom dia; Op��o 2 Boa Tarde; Op��o 3 Boa Noite; Op��o 4 At� Mais.

/*
int main(void)
{
	int opcao;
	
	printf("DIGITE UMA DAS OPCOES ABAIXO \n");
	printf("\nOpcao 1: Bom Dia \n");
	printf("Opcao 2: Boa Tarde \n");
	printf("Opcao 3: Boa Noite \n");
	printf("Opcao 4: Ate Mais \n");
	scanf("%d", &opcao);
	
	switch(opcao)
	{
		case 1:
			printf("O Usuario escolheu a opcao: Bom Dia", opcao);
		break;
		
		case 2:
			printf("O Usuario escolheu a opcao: Boa Tarde", opcao);
		break;
		
		case 3:
			printf("O Usuario escolheu a opcao: Boa Noite", opcao);
		break;
		case 4:
			printf("O Usuario escolheu a opcao: Ate Mais", opcao);
		break;
		default:
			printf("Opcao Invalida", opcao);
			
	}
	
	return 0;
}

*/

/* 2) Crie uma calculadora que leia 2 n�meros e imprima o menu abaixo:

Digite:
1 Para imprimir a soma dos dois n�meros 
2 Para imprimir a subtra��o dos dois n�meros 
3 Para imprimir a multiplica��o dos dois n�meros 
4 Para imprimir a divis�o dos dois n�meros 

Obs. Avise o usu�rio sobre divis�o por zero

*/

#include <stdio.h>

int main() {
    float num1, num2, resultado;
    int escolha;

    printf("Digite o primeiro numero: ");
    scanf("%f", &num1);

    printf("Digite o segundo numero: ");
    scanf("%f", &num2);

    printf("Digite:\n");
    printf("1 Para imprimir a soma dos dois numeros\n");
    printf("2 Para imprimir a subtracao dos dois numeros\n");
    printf("3 Para imprimir a multiplicacao dos dois numeros\n");
    printf("4 Para imprimir a divisao dos dois numeros\n");
    scanf("%d", &escolha);

    switch(escolha) {
        case 1:
            resultado = num1 + num2;
            printf("Resultado da soma: %.2f", resultado);
            break;

        case 2:
            resultado = num1 - num2;
            printf("Resultado da subtracao: %.2f", resultado);
            break;

        case 3:
            resultado = num1 * num2;
            printf("Resultado da multiplicacao: %.2f", resultado);
            break;

        case 4:
            if(num2 == 0) {
                printf("Nao e possivel dividir por zero");
            }
            else {
                resultado = num1 / num2;
                printf("Resultado da divisao: %.2f", resultado);
            }
            break;

        default:
            printf("Opcao invalida");
    }

    return 0;
}
















