#include <stdio.h>

int  i;
char str[5];

int main(void)
{
  i = 0;
  str[i] = 'A';
  printf("str[0] = %d (%c)\n", str[i] ,str[i]);/* Imprime 65 */
}
