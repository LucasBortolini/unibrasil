#include <iostream>

using namespace std;

int main() {

  int n;

  n = 10;

  n++;

  cout << n;

  return 0;

}