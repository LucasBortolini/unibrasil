// 2. Modifique o programa anterior para calcular e imprimir a m�dia dos valores do vetor.

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define TAMANHO_VETOR 5

int main() {
    int vetor[TAMANHO_VETOR];
    int i;
    float soma = 0;
    float media;

    srand(time(NULL));

    for (i = 0; i < TAMANHO_VETOR; i++) {
        vetor[i] = rand() % 100;
        soma += vetor[i];
    }

    media = soma / TAMANHO_VETOR;

    printf("Vetor preenchido com valores aleatórios:\n");
    for (i = 0; i < TAMANHO_VETOR; i++) {
        printf("%d ", vetor[i]);
    }
    printf("\n");

    printf("Média dos valores do vetor: %.2f\n", media);

    return 0;
}

