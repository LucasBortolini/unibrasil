// 6. Faça um programa em C que declare uma string e use um ponteiro para percorrê-la e imprimir cada caractere.

#include <stdio.h>

int main() {
    char str[] = "Hello";
    char *ptr = str; // Ponteiro aponta para o primeiro caractere da string
    
    printf("Caracteres da string: ");
    while (*ptr != '\0') { // Continua até encontrar o caractere nulo '\0'
        printf("%c ", *ptr); // Imprime o caractere apontado pelo ponteiro
        ptr++; // Move o ponteiro para o próximo caractere
    }
    printf("\n");
    
    return 0;
}
