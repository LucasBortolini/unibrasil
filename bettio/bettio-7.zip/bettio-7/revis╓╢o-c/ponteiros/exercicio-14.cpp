// 14. Crie uma função em C que receba uma matriz e retorne um ponteiro para o elemento de maior valor.

#include <stdio.h>

int *maiorElemento(int *matriz, int linhas, int colunas) {
    int maior = *matriz;
    int *ptrMaior = matriz;
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            if (*(matriz + i * colunas + j) > maior) {
                maior = *(matriz + i * colunas + j);
                ptrMaior = matriz + i * colunas + j;
            }
        }
    }
    return ptrMaior;
}

int main() {
    int matriz[3][3] = {{1, 2, 3},
                        {4, 5, 6},
                        {7, 8, 9}};
    
    int *ptrMaior = maiorElemento((int *)matriz, 3, 3);
    printf("O maior elemento na matriz é: %d\n", *ptrMaior);
    
    return 0;
}
