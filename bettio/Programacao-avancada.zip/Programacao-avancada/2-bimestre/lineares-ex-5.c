#include <stdio.h>
#include <stdlib.h>

struct NO {
    int info;
    struct NO* proximo;
};

void inserirNoInicio(struct NO** lista, int dado) {
    struct NO* novoNo = (struct NO*)malloc(sizeof(struct NO));
    novoNo->info = dado;
    novoNo->proximo = *lista;
    *lista = novoNo;
}

void inserirNoFim(struct NO** lista, int dado) {
    struct NO* novoNo = (struct NO*)malloc(sizeof(struct NO));
    novoNo->info = dado;
    novoNo->proximo = NULL;

    if (*lista == NULL) {
        *lista = novoNo;
    } else {
        struct NO* atual = *lista;
        while (atual->proximo != NULL) {
            atual = atual->proximo;
        }
        atual->proximo = novoNo;
    }
}

void imprimirLista(struct NO* lista) {
    struct NO* atual = lista;
    while (atual != NULL) {
        printf("%d ", atual->info);
        atual = atual->proximo;
    }
    printf("\n");
}

void localizarNo(struct NO* lista, int dado) {
    struct NO* atual = lista;
    int encontrado = 0;

    while (atual != NULL) {
        if (atual->info == dado) {
            printf("No encontrado: %d\n", atual->info);
            encontrado = 1;
            break;
        }
        atual = atual->proximo;
    }

    if (!encontrado) {
        printf("No nao encontrado!\n");
    }
}

void liberarLista(struct NO** lista) {
    struct NO* atual = *lista;
    while (atual != NULL) {
        struct NO* proximo = atual->proximo;
        free(atual);
        atual = proximo;
    }
    *lista = NULL;
}

int main() {
    struct NO* lista = NULL;
    int opcao = 0;
    char buffer[100];

    do {
        printf("\nMenu de Opcoes:\n");
        printf("1. Aloca um no no inicio\n");
        printf("2. Aloca um no no fim\n");
        printf("3. Imprime todos os nos\n");
        printf("4. Localiza um no e imprime\n");
        printf("5. Sair do programa\n");
        printf("Escolha uma opcao: ");

        fgets(buffer, sizeof(buffer), stdin);
        sscanf(buffer, "%d", &opcao);

        switch (opcao) {
            case 1: {
                int dado;
                printf("Digite o valor do no: ");
                fgets(buffer, sizeof(buffer), stdin);
                sscanf(buffer, "%d", &dado);
                inserirNoInicio(&lista, dado);
                printf("No alocado com sucesso no inicio!\n");
                break;
            }
            case 2: {
                int dado;
                printf("Digite o valor do no: ");
                fgets(buffer, sizeof(buffer), stdin);
                sscanf(buffer, "%d", &dado);
                inserirNoFim(&lista, dado);
                printf("No alocado com sucesso no fim!\n");
                break;
            }
            case 3: {
                printf("Lista de nos: ");
                imprimirLista(lista);
                break;
            }
            case 4: {
                int dado;
                printf("Digite o valor do no a ser localizado: ");
                fgets(buffer, sizeof(buffer), stdin);
                sscanf(buffer, "%d", &dado);
                localizarNo(lista, dado);
                break;
            }
            case 5: {
                liberarLista(&lista);
                printf("Saindo do programa...\n");
                break;
            }
            default:
                printf("Opcao invalida! Tente novamente.\n");
        }
    } while (opcao != 5);

    return 0;
}

