// 1. Escreva um programa em C que imprima os n�meros pares de 1 a 10.

#include <stdio.h>

int main() {
    int i;
    
    printf("Números pares de 1 a 10:\n");
    for (i = 2; i <= 10; i += 2) {
        printf("%d ", i);
    }
    
    return 0;
}
