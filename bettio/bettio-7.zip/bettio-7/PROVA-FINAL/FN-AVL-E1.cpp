#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct CADASTRO 
{
    char nome[50];
    float preco;
};

struct CADASTRO vetor[10];

int main() 
{

    for (int i = 0; i < 10; i++) 
    {
    	fflush(stdin);
        printf("Digite o nome do produto %d: ", i+1);
        scanf("%s", &vetor[i].nome);
        fflush(stdin);
        printf("Digite o preco do produto %d: ", i+1);
        scanf("%f", &vetor[i].preco);
        
    }

    float menorPreco = 0;
    int indiceMenorPreco = 0;

    for (int i = 0; i < 10; i++) 
    {
        if (vetor[i].preco < menorPreco) 
        {
            menorPreco = vetor[i].preco;
            indiceMenorPreco = i;
        }
    }

    printf("\n");
    printf("Produto com preco mais baixo:\n");
    printf("Nome: %s\n", vetor[indiceMenorPreco].nome);
    printf("Preco: %f\n", vetor[indiceMenorPreco].preco);

    return 0;
}