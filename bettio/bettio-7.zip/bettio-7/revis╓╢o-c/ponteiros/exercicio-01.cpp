/*
1.  Escreva um programa em C para declarar um ponteiro e atribuir a ele o endereço de uma variável inteira. 
Em seguida, imprima o valor da variável usando esse ponteiro.
*/

#include <stdio.h>

int main() {
    int numero = 10;
    int *ponteiro = &numero; // Declaração do ponteiro e atribuição do endereço de 'numero'
    
    printf("Valor de 'numero': %d\n", *ponteiro); // Imprime o valor de 'numero' usando o ponteiro
    
    return 0;
}
