#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main (void) {

  int *p_n1;
  p_n1 = (int*)malloc(sizeof(int));

  *p_n1 = 27;

  printf("Ponteiro: %d\n", *p_n1);
  return(0);

  (*p_n1)++;
  printf("valor incrementado: %d\n", *p_n1);

  free(p_n1);
  p_n1 = NULL;
  return(0);
}