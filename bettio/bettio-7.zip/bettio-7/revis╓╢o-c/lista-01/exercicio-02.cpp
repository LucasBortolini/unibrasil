/*
2. Elabore um programa para produzir na tela a letra C, de C Progressivo, usando a própria. Se fosse‘C’, seria assim:
CCCCC
C
C
CCCCC
*/

#include <stdio.h>

int main() {
    printf("CCCCC\n");
    printf("C\n");
    printf("C\n");
    printf("CCCCC\n");
    return 0;
}
