#include <stdio.h>

int main(void)
{
  int contador; // Variável de Controle de loop
  
  for(contador = 99; contador >=0; contador--)
  {
    printf("%d \n", contador);
  }
  
  return(0);
}