// 4. Escreva um programa em C que declare e inicialize uma variável inteira e um ponteiro para essa variável, em seguida, modifique o valor da variável através do ponteiro.

#include <stdio.h>

int main() {
    int numero = 20;
    int *ponteiro = &numero; // Ponteiro aponta para 'numero'
    
    printf("Valor original de 'numero': %d\n", numero);
    
    *ponteiro = 30; // Modifica o valor de 'numero' através do ponteiro
    printf("Novo valor de 'numero' modificado pelo ponteiro: %d\n", numero);
    
    return 0;
}
