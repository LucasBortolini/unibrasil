#include <stdio.h>

struct Pessoa {
    char nome[50];
    int idade;
};

int main() {
    struct Pessoa pessoa;

    printf("Digite seu nome: ");
    fgets(pessoa.nome, sizeof(pessoa.nome), stdin);

    printf("Digite sua idade: ");
    scanf("%d", &pessoa.idade);

    printf("\nConteúdo da estrutura:\n");
    printf("Nome: %sIdade: %d\n", pessoa.nome, pessoa.idade);

    printf("\nMapa de memória:\n");
    printf("Endereço do nome: %x\n", (void*)&pessoa.nome);
    printf("Endereço da idade: %x\n", (void*)&pessoa.idade);

    return 0;
}