#include <iostream>

using namespace std;

int main() {

  int idade;
  float pi = 3.14;

  idade = 20;

  cout << idade << endl;
  cout << pi << endl;

  return 0;
}