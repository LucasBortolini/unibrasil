// 13 Crie uma função capaz de substituir todos os números negativos de uma matriz por seu módulo.

#include <stdio.h>
#include <stdlib.h>

#define LINHAS 3
#define COLUNAS 3

void substituirNegativos(int matriz[LINHAS][COLUNAS]) {
    for (int i = 0; i < LINHAS; i++) {
        for (int j = 0; j < COLUNAS; j++) {
            if (matriz[i][j] < 0)
                matriz[i][j] = abs(matriz[i][j]);
        }
    }
}

int main() {
    int matriz[LINHAS][COLUNAS];

    printf("Digite os elementos da matriz %dx%d:\n", LINHAS, COLUNAS);
    for (int i = 0; i < LINHAS; i++) {
        for (int j = 0; j < COLUNAS; j++) {
            scanf("%d", &matriz[i][j]);
        }
    }

    substituirNegativos(matriz);

    printf("Matriz resultante:\n");
    for (int i = 0; i < LINHAS; i++) {
        for (int j = 0; j < COLUNAS; j++) {
            printf("%d ", matriz[i][j]);
        }
        printf("\n");
    }

    return 0;
}
