#include <stdio.h>
#include <conio.h>
#include <windows.h>
#include <locale.h>

/* 
    Aloque uma área de memória com malloc para armazenar uma struct com nome e telefone (ambos vetor de char). Preencha os dados usando struct. Imprima os dados.
*/

// Criando a struct CONTATO
struct Contato 
{
    char nome[50];
    char telefone[20];
};

int main() 
{
    struct Contato *ptr = (struct Contato*)malloc(sizeof(struct Contato)); // Aloca memória para a struct Contato

    // Preenche os dados da struct
    strcpy(ptr->nome, "Joao");
    strcpy(ptr->telefone, "123456789");

    // Imprime os dados da struct
    printf("Nome: %s\n", ptr->nome);
    printf("Telefone: %s\n", ptr->telefone);

    free(ptr); // Desaloca a memória alocada

    return 0;
}
