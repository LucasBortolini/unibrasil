#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct FILIACAO
{
	int idade;
	char nome[100];
    char sexo;
};

struct PESSOA
{
	int cpf;
	char nome[100];
	struct FILIACAO filho1;
	struct FILIACAO filho2;	
};

int main()
{
	struct PESSOA pessoa ;	
	fflush(stdin);
	printf("Coloque seu nome\n");
	scanf("%s", &pessoa.nome);
	
	fflush(stdin);
	printf("Coloque seu cpf\n");
	scanf("%d",&pessoa.cpf);
	
	fflush(stdin);
	printf("Insira o nome do filho 1\n");
	scanf("%s",&pessoa.filho1.nome);
	
	fflush(stdin);
	printf("Insira a idade do filho 1\n");
	scanf("%d",&pessoa.filho1.idade);
	
	fflush(stdin);
	printf("Insira o sexo do filho 1\n");
	scanf("%c",&pessoa.filho1.sexo);

    fflush(stdin);
	printf("Insira o nome do filho 2\n");
	scanf("%s",&pessoa.filho2.nome);
	
	fflush(stdin);
	printf("Insira a idade do filho 2\n");
	scanf("%d",&pessoa.filho2.idade);
	
	fflush(stdin);
	printf("Insira o sexo do filho 2\n");
	scanf("%c",&pessoa.filho2.sexo);
	
	
	printf("Dados do Usuario:\n");
	printf("\nNome: %s\n",pessoa.nome);
	printf("Idade: %d\n",pessoa.cpf);
	printf("Nome do filho 1: %s\n",pessoa.filho1.nome);
	printf("Idade do filho 1: %d\n",pessoa.filho1.idade);
	printf("Sexo do filho 1: %c\n",pessoa.filho1.sexo);
	printf("Nome do filho 2: %s\n",pessoa.filho2.nome);
	printf("Idade do filho 2: %d\n",pessoa.filho2.idade);
	printf("Sexo do filho 2: %c\n",pessoa.filho2.sexo);
	
	return(0);
    
  }