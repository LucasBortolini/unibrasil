// 17. Implemente uma função em C que receba uma árvore binária e retorne a altura da árvore usando ponteiros.

#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node *left;
    struct Node *right;
} Node;

Node *criarNo(int valor) {
    Node *novoNo = (Node *)malloc(sizeof(Node));
    novoNo->data = valor;
    novoNo->left = novoNo->right = NULL;
    return novoNo;
}

int max(int a, int b) {
    return (a > b) ? a : b;
}

int alturaArvore(Node *raiz) {
    if (raiz == NULL) return 0;
    return 1 + max(alturaArvore(raiz->left), alturaArvore(raiz->right));
}

int main() {
    Node *raiz = criarNo(1);
    raiz->left = criarNo(2);
    raiz->right = criarNo(3);
    raiz->left->left = criarNo(4);
    raiz->left->right = criarNo(5);
    
    printf("A altura da árvore é: %d\n", alturaArvore(raiz));
    
    return 0;
}
