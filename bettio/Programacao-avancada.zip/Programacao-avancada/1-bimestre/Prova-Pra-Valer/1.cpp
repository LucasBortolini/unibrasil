#include <stdio.h>

int main () 
{
  int tensao, corrente, potencia;

  fflush(stdin); // limpeza de buffer
  printf("Digite a tensao:\n");
  scanf("%d", &tensao);

  fflush(stdin); // limpeza de buffer
  printf("Digite a corrente:\n");
  scanf("%d", &corrente);

  potencia = tensao * corrente;

  printf("A potencia eh de: %d W \n", potencia);

  
} 