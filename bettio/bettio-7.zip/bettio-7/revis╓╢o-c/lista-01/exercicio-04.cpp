/*
4. Pinheiro  - Implemente um programa que desenhe um "pinheiro" na tela, similar ao abaixo.
Enriqueça o desenho com outros caracteres, simulando enfeites.
       X
      XXX
     XXXXX
    XXXXXXX
   XXXXXXXXX
  XXXXXXXXXXX
 XXXXXXXXXXXXX
XXXXXXXXXXXXXXX
       XX
       XX
      XXXX
*/

#include <stdio.h>

int main() {
    int altura = 8; // Altura do pinheiro

    for (int i = 0; i < altura; i++) {
        for (int j = 0; j < altura - i; j++)
            printf(" ");
        for (int k = 0; k < (2 * i + 1); k++)
            printf("X");
        printf("\n");
    }

    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < altura - 1; j++)
            printf(" ");
        printf("XX\n");
    }

    return 0;
}
