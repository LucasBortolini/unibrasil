#include <stdio.h>

int main(void)
{
  int x = 100;
  while (x > 0)
  {
    x--; // ou x++
    printf("X:%d\n",x);
  }
}
