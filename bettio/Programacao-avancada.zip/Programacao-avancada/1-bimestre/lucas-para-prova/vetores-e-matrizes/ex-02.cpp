// 2.Crie um vetor de 20 posições com a seguinte sequencia numérica
// 2,4,6,8,10,... Após o preenchimento imprima o vetor

#include <stdio.h>

int main() {
  int vetor1[20] = {2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38, 40};
  int i;

    // Realiza a operação e armazena o resultado no terceiro vetor
  for (int i = 0; i < 20; i++) {
    printf("%d\n", vetor1[i]);
  }
}