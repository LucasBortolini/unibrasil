// 16. Escreva um programa em C que implemente uma fila usando ponteiros e tenha funções para enfileirar, desenfileirar e imprimir os elementos.

#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node *next;
} Node;

typedef struct {
    Node *front;
    Node *rear;
} Queue;

Queue *criarFila() {
    Queue *fila = (Queue *)malloc(sizeof(Queue));
    fila->front = fila->rear = NULL;
    return fila;
}

void enfileirar(Queue *fila, int valor) {
    Node *novoNo = (Node *)malloc(sizeof(Node));
    novoNo->data = valor;
    novoNo->next = NULL;
    if (fila->rear == NULL) {
        fila->front = fila->rear = novoNo;
        return;
    }
    fila->rear->next = novoNo;
    fila->rear = novoNo;
}

void desenfileirar(Queue *fila) {
    if (fila->front == NULL) return;
    Node *temp = fila->front;
    fila->front = fila->front->next;
    if (fila->front == NULL) fila->rear = NULL;
    free(temp);
}

void imprimirFila(Queue *fila) {
    Node *temp = fila->front;
    while (temp != NULL) {
        printf("%d ", temp->data);
        temp = temp->next;
    }
    printf("\n");
}

int main() {
    Queue *fila = criarFila();
    enfileirar(fila, 10);
    enfileirar(fila, 20);
    enfileirar(fila, 30);
    printf("Fila após enfileirar 10, 20 e 30: ");
    imprimirFila(fila);
    
    desenfileirar(fila);
    printf("Fila após desenfileirar um elemento: ");
    imprimirFila(fila);
    
    return 0;
}
