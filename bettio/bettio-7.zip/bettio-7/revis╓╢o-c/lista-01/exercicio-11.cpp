/* 11. Faça um programa que crie um vetor de pessoas. Os dados de uma pessoa devem ser armazenados em um variavel do tipo struct. 
O programa deve permitir que o usuário digite o nome de 3 pessoas e a seguir imprimi os dados de todas as pessoas. A struct deve armazenar os dados de idade, peso e altura.*/

#include <stdio.h>

#define MAX_PESSOAS 3

struct Pessoa {
    char nome[50];
    int idade;
    float peso;
    float altura;
};

int main() {
    struct Pessoa pessoas[MAX_PESSOAS];

    printf("Digite os dados das pessoas:\n");
    for (int i = 0; i < MAX_PESSOAS; i++) {
        printf("Pessoa %d:\n", i + 1);
        printf("Nome: ");
        scanf("%s", pessoas[i].nome);
        printf("Idade: ");
        scanf("%d", &pessoas[i].idade);
        printf("Peso: ");
        scanf("%f", &pessoas[i].peso);
        printf("Altura: ");
        scanf("%f", &pessoas[i].altura);
    }

    printf("\nDados das pessoas:\n");
    for (int i = 0; i < MAX_PESSOAS; i++) {
        printf("Pessoa %d:\n", i + 1);
        printf("Nome: %s\n", pessoas[i].nome);
        printf("Idade: %d\n", pessoas[i].idade);
        printf("Peso: %.2f\n", pessoas[i].peso);
        printf("Altura: %.2f\n", pessoas[i].altura);
    }

    return 0;
}
