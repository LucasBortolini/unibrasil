// 9. Faça um programa em C que leia uma matriz usando ponteiros e imprima sua transposta.

#include <stdio.h>

#define LINHAS 3
#define COLUNAS 3

void imprimirMatriz(int *matriz, int linhas, int colunas) {
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            printf("%d ", *(matriz + i * colunas + j));
        }
        printf("\n");
    }
}

void imprimirTransposta(int *matriz, int linhas, int colunas) {
    for (int i = 0; i < colunas; i++) {
        for (int j = 0; j < linhas; j++) {
            printf("%d ", *(matriz + j * colunas + i));
        }
        printf("\n");
    }
}

int main() {
    int matriz[LINHAS][COLUNAS] = {{1, 2, 3},
                                    {4, 5, 6},
                                    {7, 8, 9}};
                                    
    printf("Matriz original:\n");
    imprimirMatriz((int *)matriz, LINHAS, COLUNAS);
    
    printf("\nTransposta da matriz:\n");
    imprimirTransposta((int *)matriz, LINHAS, COLUNAS);
    
    return 0;
}
