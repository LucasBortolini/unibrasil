// 2.  Modifique o programa anterior para calcular e imprimir a soma dos elementos da matriz.

#include <stdio.h>

int main() {
    int matriz[3][3];
    int soma = 0;
    
    printf("Informe os valores da matriz 3x3:\n");
    
    // Preenchendo a matriz com valores informados pelo usuário
    for(int i = 0; i < 3; i++) {
        for(int j = 0; j < 3; j++) {
            printf("Digite o valor para a posição [%d][%d]: ", i, j);
            scanf("%d", &matriz[i][j]);
            soma += matriz[i][j];
        }
    }
    
    // Imprimindo a matriz preenchida
    printf("Matriz informada:\n");
    for(int i = 0; i < 3; i++) {
        for(int j = 0; j < 3; j++) {
            printf("%d ", matriz[i][j]);
        }
        printf("\n");
    }
    
    // Imprimindo a soma dos elementos da matriz
    printf("Soma dos elementos da matriz: %d\n", soma);
    
    return 0;
}


