#include <stdio.h>
#include <stdlib.h>

int main(int argc, char const *argv[])
{
  struct NO
  {
      int info;
      struct NO *proximo;
  };

  struct NO *aux = NULL;
  struct NO *topo = NULL; // obs. Struct NO topo;
  
  topo = (struct NO*) malloc(sizeof(struct NO));
  topo -> info = 10;
  topo -> proximo = NULL;
  
  aux = topo;
  topo = (struct NO*) malloc(sizeof(struct NO));
  topo -> info = 11;
  topo -> proximo = NULL;
  topo -> proximo = aux;

  aux = topo;
  topo = (struct NO*) malloc(sizeof(struct NO));
  topo -> info = 12;
  topo -> proximo = NULL;
  topo -> proximo = aux;

  aux = topo;
  topo = (struct NO*) malloc(sizeof(struct NO));
  topo -> info = 13;
  topo -> proximo = NULL;
  topo -> proximo = aux;  

  aux = topo;
  topo = (struct NO*) malloc(sizeof(struct NO));
  topo -> info = 14;
  topo -> proximo = NULL;
  topo -> proximo = aux;

  aux = topo;
  int i = 0;
  while (aux != NULL) {
    printf("atual: %p\ninfo: %d\nprox:%p\n------------\n", aux, aux -> info, aux -> proximo);
    aux = aux -> proximo;
  }
}