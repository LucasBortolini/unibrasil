#include <stdio.h>

int main (void) 
{
  float x;
  float w;
  float y;
  float z;

  fflush(stdin); // limpeza de buffer
  printf("Digite o primeiro numero: \n");
  scanf("%f", &x);

  fflush(stdin); // limpeza de buffer
  printf("Digite o segundo numero: \n");
  scanf("%f", &w);

  fflush(stdin); // limpeza de buffer
  printf("Digite o segundo numero: \n");
  scanf("%f", &y);

  fflush(stdin); // limpeza de buffer
  printf("Digite o segundo numero: \n");
  scanf("%f", &z);

  printf("a media entre X, W, Y e Z eh= %.1f\n", (x + w + y + z) / 4);


  // %d     inteiro decimal
  // %f     float
  // %lf    double
  // %c     char
  // %s     string
}
