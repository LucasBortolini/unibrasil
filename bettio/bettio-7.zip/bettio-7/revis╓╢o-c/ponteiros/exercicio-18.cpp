// 18. Faça um programa em C que utilize ponteiros para manipular arquivos, permitindo ao usuário criar, escrever, ler e deletar informações em um arquivo.

#include <stdio.h>

int main() {
    FILE *arquivo;
    char texto[100];
    
    // Escrever em um arquivo
    arquivo = fopen("arquivo.txt", "w");
    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo.");
        return 1;
    }
    fprintf(arquivo, "Olá, mundo!\n");
    fclose(arquivo);
    
    // Ler de um arquivo
    arquivo = fopen("arquivo.txt", "r");
    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo.");
        return 1;
    }
    fgets(texto, sizeof(texto), arquivo);
    printf("Conteúdo do arquivo: %s", texto);
    fclose(arquivo);
    
    // Deletar um arquivo
    if (remove("arquivo.txt") == 0) {
        printf("Arquivo deletado com sucesso.");
    } else {
        printf("Erro ao deletar o arquivo.");
    }
    
    return 0;
}
