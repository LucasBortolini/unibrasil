#include <stdio.h>

int main (void) {
  float x;
  float y;

  fflush(stdin); // limpeza de buffer
  printf("Digite o preco do primeiro produto: \n");
  scanf("%f", &x);

  fflush(stdin); // limpeza de buffer
  printf("Digite o preco do segundo produto: \n");
  scanf("%f", &y);

  if (x > y) {
    printf("o primeiro valor eh maior que o segundo");
  }

  


  // %d     inteiro decimal
  // %f     float
  // %lf    double
  // %c     char
  // %s     string
}
