#include <stdio.h>
#include <stdlib.h>

/*  
    Na linguagem C resolva o seguinte exercicio: 

    Criar um programa para manipular uma lista simplesmente encadeada
    O programa deverá apresentar um menu com as seguintes opções:
    Inlcusao no inicio da lista
    Inlcusao no fim da lista
    Remocao do inicio da lista
    Remocao do fim da lista
    Impressao da lista com valor do topo, e endereço e valor dos nós que compõe a lista.

*/

typedef struct Node 
{
    int value;
    struct Node* next;
} Node;

// Função para criar um novo nó com o valor especificado
Node* createNode(int value) 
{
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->value = value;
    newNode->next = NULL;
    return newNode;
}

// Função para incluir um novo nó no inicio da lista
void insertAtBeginning(Node** head, int value) 
{
    Node* newNode = createNode(value);
    newNode->next = *head;
    *head = newNode;
    printf("Elemento %d incluido no inicio da lista.\n", value);
}

// Função para incluir um novo nó no fim da lista
void insertAtEnd(Node** head, int value) 
{
    Node* newNode = createNode(value);
    if (*head == NULL) 
    {
        *head = newNode;
    } 
    else 
    {
        Node* current = *head;
        while (current->next != NULL) 
        {
            current = current->next;
        }
        current->next = newNode;
    }
    printf("Elemento %d incluido no fim da lista.\n", value);
}

// Função para remover o nó do inicio da lista
void removeFromBeginning(Node** head) 
{
    if (*head == NULL) 
    {
        printf("A lista está vazia.\n");
    } 
    else 
    {
        Node* temp = *head;
        *head = (*head)->next;
        printf("Elemento %d removido do inicio da lista.\n", temp->value);
        free(temp);
    }
}

// Função para remover o nó do fim da lista
void removeFromEnd(Node** head) 
{
    if (*head == NULL) 
    {
        printf("A lista está vazia.\n");
    } 
    else if ((*head)->next == NULL) 
    {
        Node* temp = *head;
        *head = NULL;
        printf("Elemento %d removido do fim da lista.\n", temp->value);
        free(temp);
    } 
    else 
    {
        Node* current = *head;
        while (current->next->next != NULL) 
        {
            current = current->next;
        }
        Node* temp = current->next;
        current->next = NULL;
        printf("Elemento %d removido do fim da lista.\n", temp->value);
        free(temp);
    }
}

// Função para imprimir a lista
void printList(Node* head) 
{
    if (head == NULL) 
    {
        printf("A lista está vazia.\n");
    } 
    else 
    {
        printf("Topo: %d\n", head->value);
        printf("Endereço\tValor\n");
        Node* current = head;
        while (current != NULL) 
        {
            printf("%p\t%d\n", current, current->value);
            current = current->next;
        }
    }
}

// Função para liberar a memória alocada pela lista
void freeList(Node* head) 
{
    Node* current = head;
    while (current != NULL) 
    {
        Node* temp = current;
        current = current->next;
        free(temp);
    }
}

int main() 
{
    Node* head = NULL;
    int choice, value;

    do {
        printf("\nMenu:\n");
        printf("1. Inlcusao no inicio da lista\n");
        printf("2. Inlcusao no fim da lista\n");
        printf("3. Remocao do inicio da lista\n");
        printf("4. Remocao do fim da lista\n");
        printf("5. Impressao da lista\n");
        printf("0. Sair\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &choice);

        switch (choice) 
        {
            case 1:
                printf("Digite o valor a ser incluido: ");
                scanf("%d", &value);
                insertAtBeginning(&head, value);
                break;
            case 2:
                printf("Digite o valor a ser incluido: ");
                scanf("%d", &value);
                insertAtEnd(&head, value);
                break;
            case 3:
                removeFromBeginning(&head);
                break;
            case 4:
                removeFromEnd(&head);
                break;
            case 5:
                printList(head);
                break;
            case 0:
                printf("Encerrando o programa.\n");
                break;
            default:
                printf("Opção invalida. Tente novamente.\n");
                break;
        }
    } while (choice != 0);

    freeList(head);

    return 0;
}
