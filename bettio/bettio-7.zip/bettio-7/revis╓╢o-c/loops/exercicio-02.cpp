// 2. Modifique o programa anterior para imprimir os n�meros de 1 a 10 em ordem reversa.

#include <stdio.h>

int main() {
    int i;
    
    printf("Números de 1 a 10 em ordem reversa:\n");
    for (i = 10; i >= 1; i--) {
        printf("%d ", i);
    }
    
    return 0;
}
