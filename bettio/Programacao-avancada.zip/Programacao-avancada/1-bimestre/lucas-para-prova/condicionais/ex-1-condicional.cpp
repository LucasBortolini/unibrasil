// 1) LEIA O PREÇO DE DOIS PRODUTOS E INFORME SE O PRIMERIO É MAIOR QUE O SEGUNDO;

#include <stdio.h>
int main(void) {

  float preco1, preco2;
  
  fflush(stdin);
  printf("Entre com o valor 1\n");
  scanf("%f", &preco1);
  
  fflush(stdin);
  printf("Entre com o valor 2\n");
  scanf("%f", &preco2);
  
  if(preco1 > preco2)
  {
    printf("Primeiro Valor eh Maior que o Segundo\n");
  }
  else
  {
    printf("Primeiro Valor eh Menor que o Segundo\n");
  }
}