#include <stdio.h>
#include <conio.h>
#include <windows.h>
#include <locale.h>

/*
    Na linguagem C aloque 5 áreas de memória com malloc para armazenar 5 números inteiros, cada alocação deve ser colocada em um vetor de ponteiros: int *vet[5];
    Imprima os valores usando o vetor de ponteiros.
*/

int main() 
{
    int *vet[5];  // Vetor de ponteiros para inteiros
    int i;

    // Alocação de memória para cada número inteiro usando malloc
    for (i = 0; i < 5; i++) 
    {
        vet[i] = (int*)malloc(sizeof(int));
    }

    // Atribuição de valores aos números inteiros
    for (i = 0; i < 5; i++) 
    {
        *vet[i] = i + 1;
    }

    // Impressão dos valores utilizando o vetor de ponteiros
    for (i = 0; i < 5; i++) 
    {
        printf("%d\n", *vet[i]);
    }

    // Liberação da memória alocada com malloc
    for (i = 0; i < 5; i++) 
    {
        free(vet[i]);
    }

    return 0;
}
