// 10. Escreva um programa em C que receba uma string do usuário e conte quantas vogais ela contém usando ponteiros.

#include <stdio.h>

int contarVogais(char *str) {
    int vogais = 0;
    while (*str != '\0') {
        if (*str == 'a' || *str == 'e' || *str == 'i' || *str == 'o' || *str == 'u' ||
            *str == 'A' || *str == 'E' || *str == 'I' || *str == 'O' || *str == 'U') {
            vogais++;
        }
        str++; // Move o ponteiro para o próximo caractere
    }
    return vogais;
}

int main() {
    char texto[100];
    printf("Digite uma string: ");
    fgets(texto, sizeof(texto), stdin);
    
    int numVogais = contarVogais(texto);
    printf("Número de vogais na string: %d\n", numVogais);
    
    return 0;
}
